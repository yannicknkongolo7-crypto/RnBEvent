const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const s3 = new S3Client({ region: 'us-east-2' });
const ses = new SESClient({ region: 'us-east-2' });

const BUCKET = 'rnbevents716';
const KEY = 'clients.json';
const ADMIN_DATA_KEY = 'admin-data.json';
const RECOVERY_EMAIL = 'rnbevents716@gmail.com';
const RESET_CODE_KEY = 'admin-reset-code.json';
const HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Content-Type': 'application/json'
};

function respond(code, data) {
    return { statusCode: code, headers: HEADERS, body: JSON.stringify(data) };
}

async function readClients() {
    const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: KEY }));
    const text = await res.Body.transformToString();
    return JSON.parse(text);
}

async function writeClients(clients) {
    await s3.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: KEY,
        Body: JSON.stringify(clients),
        ContentType: 'application/json',
        CacheControl: 'no-cache, no-store, must-revalidate'
    }));
}

/* ── Section sanitizers ─────────────────────────── */

function sanitizeUrl(url) {
    url = String(url || '').slice(0, 2000);
    return /^https?:\/\//i.test(url) ? url : '';
}

/* Accepts https:// URLs and data: image URIs (device uploads) */
function sanitizeImageSrc(src) {
    src = String(src || '');
    if (/^https?:\/\//i.test(src)) return src.slice(0, 3000);
    if (/^data:image\/(jpeg|png|webp|gif);base64,/.test(src)) return src.slice(0, 200000);
    return '';
}

function sanitizeTimeline(data) {
    if (!Array.isArray(data)) return [];
    const STATUSES = ['upcoming', 'in-progress', 'done'];
    return data.slice(0, 50).map(item => ({
        date: String(item.date || '').slice(0, 100),
        milestone: String(item.milestone || '').slice(0, 200),
        notes: String(item.notes || '').slice(0, 500),
        status: STATUSES.includes(item.status) ? item.status : 'upcoming'
    })).filter(item => item.milestone.trim());
}

function sanitizeVendors(data) {
    if (!Array.isArray(data)) return [];
    return data.slice(0, 30).map(item => ({
        name: String(item.name || '').slice(0, 200),
        role: String(item.role || '').slice(0, 100),
        phone: String(item.phone || '').replace(/[^\d\s\-\+\(\)]/g, '').slice(0, 30),
        email: String(item.email || '').slice(0, 200),
        status: String(item.status || 'TBD').slice(0, 50)
    })).filter(item => item.name.trim());
}

function sanitizeDocuments(data) {
    if (!Array.isArray(data)) return [];
    return data.slice(0, 50).map(item => ({
        name: String(item.name || '').slice(0, 200),
        type: String(item.type || 'Document').slice(0, 100),
        url: sanitizeUrl(item.url),
        date: String(item.date || '').slice(0, 50)
    })).filter(item => item.name.trim() && item.url);
}

function sanitizeGallery(data) {
    if (!Array.isArray(data)) return [];
    return data.slice(0, 100).map(item => {
        if (typeof item === 'string') return { url: sanitizeImageSrc(item), caption: '' };
        return {
            url: sanitizeImageSrc(String(item.url || '')),
            caption: String(item.caption || '').slice(0, 300)
        };
    }).filter(item => item.url);
}

function sanitizeMoodboard(data) {
    if (!data || typeof data !== 'object') return { palette: [], images: [], description: '' };
    return {
        description: String(data.description || '').slice(0, 2000),
        palette: Array.isArray(data.palette)
            ? data.palette.slice(0, 20).map(hex => String(hex).replace(/[^#a-fA-F0-9]/g, '').slice(0, 10))
            : [],
        images: Array.isArray(data.images)
            ? data.images.slice(0, 50).map(img => {
                if (typeof img === 'string') return { url: sanitizeImageSrc(img), caption: '' };
                return { url: sanitizeImageSrc(String(img.url || '')), caption: String(img.caption || '').slice(0, 300) };
            }).filter(img => img.url)
            : []
    };
}

function sanitizeAgreement(data) {
    if (!data || typeof data !== 'object') return { status: 'pending', coupleSignature: '', coupleSignedAt: '', plannerSignature: '', plannerSignedAt: '' };
    const STATUSES = ['pending', 'couple-signed', 'fully-executed'];
    return {
        status: STATUSES.includes(data.status) ? data.status : 'pending',
        coupleSignature:  String(data.coupleSignature  || '').slice(0, 300),
        coupleSignedAt:   String(data.coupleSignedAt   || '').slice(0, 50),
        plannerSignature: String(data.plannerSignature || '').slice(0, 300),
        plannerSignedAt:  String(data.plannerSignedAt  || '').slice(0, 50)
    };
}

const SECTION_SANITIZERS = {
    timeline: sanitizeTimeline,
    vendors: sanitizeVendors,
    documents: sanitizeDocuments,
    gallery: sanitizeGallery,
    moodboard: sanitizeMoodboard,
    agreement: sanitizeAgreement
};

/* ── Find client by any of 3 access hashes ──────── */
function findClientByAnyHash(clients, hash) {
    return clients.findIndex(c =>
        c.codeHash === hash ||
        c.plannerCodeHash === hash ||
        c.teamCodeHash === hash
    );
}

/* ── Append an entry to the client's editLog ─────── */
function appendEditLog(client, entry) {
    const ROLES = ['couple', 'planner', 'rnbTeam'];
    if (!client.editLog) client.editLog = [];
    client.editLog = client.editLog.slice(-49);
    client.editLog.push({
        ts:       String(entry.ts       || new Date().toISOString()).slice(0, 50),
        role:     ROLES.includes(entry.role) ? entry.role : 'unknown',
        roleName: String(entry.roleName || '').slice(0, 100),
        action:   String(entry.action   || '').slice(0, 200)
    });
}

/* ── Admin CRM data (S3) ───────────────────────── */
async function readAdminData() {
    try {
        const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: ADMIN_DATA_KEY }));
        const text = await res.Body.transformToString();
        return JSON.parse(text);
    } catch (e) {
        // NoSuchKey on first use — return empty structure
        return { prospects: [], tasks: [], content: {}, adminCodeHash: '' };
    }
}

async function writeAdminData(data) {
    await s3.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: ADMIN_DATA_KEY,
        Body: JSON.stringify(data),
        ContentType: 'application/json',
        CacheControl: 'no-cache, no-store, must-revalidate'
    }));
}

/* ── Create admin task via S3 ─────────────────── */
async function createAdminTask(taskObj) {
    try {
        const data = await readAdminData();
        const tasks = Array.isArray(data.tasks) ? data.tasks : [];
        tasks.unshift(taskObj);
        await writeAdminData({ ...data, tasks });
    } catch (e) {
        console.error('Failed to create admin task:', e);
    }
}

/* ── Register a new lead/prospect in Admin CRM ── */
async function createAdminProspect(prospectObj) {
    try {
        const data = await readAdminData();
        const prospects = Array.isArray(data.prospects) ? data.prospects : [];
        prospects.unshift(prospectObj);
        await writeAdminData({ ...data, prospects });
    } catch (e) {
        console.error('Failed to register prospect:', e);
    }
}

/* ── IP geolocation (ip-api.com free tier) ───── */
async function geoLookup(ip) {
    if (!ip || ip === '127.0.0.1' || ip === '::1') return { city: '', country: '' };
    try {
        const res = await fetch(`http://ip-api.com/json/${ip}?fields=city,country`, {
            signal: AbortSignal.timeout(1500)
        });
        if (!res.ok) return { city: '', country: '' };
        const data = await res.json();
        return {
            city:    String(data.city    || '').slice(0, 100),
            country: String(data.country || '').slice(0, 100)
        };
    } catch (e) {
        return { city: '', country: '' };
    }
}

exports.handler = async (event) => {
    if (event.requestContext && event.requestContext.http && event.requestContext.http.method === 'OPTIONS') {
        return respond(200, '');
    }

    const path = (event.rawPath || event.requestContext.http.path || '').replace(/\/$/, '');
    const method = (event.requestContext?.http?.method || 'POST').toUpperCase();

    try {
        const body = JSON.parse(event.body || '{}');

        /* ── Admin data: GET all (replaces Google Apps Script) ── */
        if (path === '/admin-data' && body.action === 'get') {
            const data = await readAdminData();
            return respond(200, data);
        }

        /* ── Admin data: POST/save (replaces Google Apps Script) ── */
        if (path === '/admin-data' && method === 'POST') {
            const current = await readAdminData();
            // Merge: only update keys that are present in body
            const updated = { ...current };
            if (Array.isArray(body.prospects))    updated.prospects     = body.prospects;
            if (Array.isArray(body.tasks))         updated.tasks         = body.tasks;
            if (body.content && typeof body.content === 'object') {
                updated.content = { ...(current.content || {}), ...body.content };
            }
            if (typeof body.adminCodeHash === 'string') updated.adminCodeHash = body.adminCodeHash;
            await writeAdminData(updated);
            return respond(200, { ok: true, ts: new Date().toISOString() });
        }

        /* ── Admin: full publish ────────────────────── */
        if (path === '/upload-clients') {
            if (!body.clients || !Array.isArray(body.clients)) {
                return respond(400, { ok: false, error: 'Missing clients array' });
            }

            /* Merge: admin controls basic fields + deletions; S3 owns portal section data.
               - Clients absent from incoming list are DELETED (that's the fix).
               - For kept clients, preserve portal sections from S3 so in-progress
                 portal work is never overwritten by a stale admin session. */
            const PORTAL_SECTIONS = ['timeline','vendors','documents','gallery','moodboard','agreement','editLog','trackingNotes'];
            let existing = [];
            try { existing = await readClients(); } catch (e) { /* first write */ }
            if (!Array.isArray(existing)) existing = [];

            const existingById = {};
            existing.forEach(c => { if (c && c.id) existingById[c.id] = c; });

            const merged = body.clients.map(incoming => {
                const s3 = existingById[incoming.id];
                if (!s3) return incoming; // new client
                // Merge: take admin fields from incoming, portal sections from S3
                const out = Object.assign({}, incoming);
                PORTAL_SECTIONS.forEach(k => { if (s3[k] !== undefined) out[k] = s3[k]; });
                return out;
            });
            // Clients not in incoming are simply omitted — that's the delete

            await writeClients(merged);
            return respond(200, { ok: true, count: merged.length });
        }

        /* ── Client: update own tracking notes ──────── */
        if (path === '/update-client-notes') {
            const { codeHash, clientTodos, plannerTodos, teamTodos, editLogEntry } = body;
            if (!codeHash || typeof codeHash !== 'string') return respond(400, { ok: false, error: 'Missing codeHash' });

            const ALLOWED = ['pending', 'in-progress', 'done', 'not-applicable'];
            const ROLES   = ['couple', 'planner', 'rnbTeam'];

            function sanitizeTodoList(arr) {
                if (!Array.isArray(arr)) return null;
                return arr.slice(0, 100).map(item => {
                    const out = {
                        text:   String(item.text   || '').slice(0, 500),
                        status: ALLOWED.includes(item.status) ? item.status : 'pending'
                    };
                    if (item.addedAt)  out.addedAt  = String(item.addedAt).slice(0, 50);
                    if (item.addedBy && ROLES.includes(item.addedBy)) out.addedBy = item.addedBy;
                    return out;
                }).filter(item => item.text.trim().length > 0);
            }

            const cleanClientTodos  = clientTodos  !== undefined ? sanitizeTodoList(clientTodos)  : undefined;
            const cleanPlannerTodos = plannerTodos  !== undefined ? sanitizeTodoList(plannerTodos) : undefined;
            const cleanTeamTodos    = teamTodos     !== undefined ? sanitizeTodoList(teamTodos)    : undefined;

            if (clientTodos !== undefined && cleanClientTodos === null)
                return respond(400, { ok: false, error: 'clientTodos must be an array' });

            const clients = await readClients();
            const idx = findClientByAnyHash(clients, codeHash);
            if (idx === -1) return respond(404, { ok: false, error: 'Client not found' });

            if (!clients[idx].trackingNotes) clients[idx].trackingNotes = {};
            if (cleanClientTodos  !== undefined && cleanClientTodos  !== null) clients[idx].trackingNotes.clientTodos  = cleanClientTodos;
            if (cleanPlannerTodos !== undefined && cleanPlannerTodos !== null) clients[idx].trackingNotes.plannerTodos = cleanPlannerTodos;
            if (cleanTeamTodos    !== undefined && cleanTeamTodos    !== null) clients[idx].trackingNotes.teamTodos    = cleanTeamTodos;

            if (editLogEntry && typeof editLogEntry === 'object') {
                appendEditLog(clients[idx], editLogEntry);
            }

            await writeClients(clients);
            return respond(200, { ok: true });
        }

        /* ── Client: update any portal section ──────── */
        if (path === '/update-client-section') {
            const { codeHash, section, data, editLogEntry } = body;
            if (!codeHash || typeof codeHash !== 'string') return respond(400, { ok: false, error: 'Missing codeHash' });
            if (!SECTION_SANITIZERS[section]) return respond(400, { ok: false, error: 'Invalid section: ' + section });

            const clients = await readClients();
            const idx = findClientByAnyHash(clients, codeHash);
            if (idx === -1) return respond(404, { ok: false, error: 'Client not found' });

            const oldAgreementStatus = (clients[idx].agreement || {}).status;
            clients[idx][section] = SECTION_SANITIZERS[section](data);

            if (editLogEntry && typeof editLogEntry === 'object') {
                appendEditLog(clients[idx], editLogEntry);
            }

            await writeClients(clients);

            /* Auto-send receipt + create admin task when agreement becomes fully-executed */
            if (section === 'agreement' && clients[idx].agreement.status === 'fully-executed' && oldAgreementStatus !== 'fully-executed') {
                const c = clients[idx];
                const clientName = c.fullName || c.firstName || 'Client';
                const clientEmail = c.email || '';
                const agr = c.agreement;

                /* Send receipt email via SES */
                if (clientEmail) {
                    const receiptHtml = `
<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">
<tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,'Times New Roman',serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:8px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">Crafting Moments That Last Forever</p>
</td></tr>
<tr><td style="padding:40px 30px">
  <h2 style="margin:0 0 20px;color:#2d3a2d;font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400">Agreement Fully Executed</h2>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">Dear ${clientName.replace(/[<>"]/g, '')},</p>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">Your Event Planning Agreement has been fully signed by all parties. This email serves as your official receipt and confirmation.</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <p style="margin:0 0 12px;color:#527141;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:600">Agreement Details</p>
      <table width="100%" cellpadding="4" cellspacing="0">
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Event</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(c.eventType || 'Event').replace(/[<>"]/g, '')}${c.eventDate ? ' - ' + c.eventDate.replace(/[<>"]/g, '') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Client Signed</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(agr.coupleSignature || '').replace(/[<>"]/g, '')} on ${agr.coupleSignedAt ? new Date(agr.coupleSignedAt).toLocaleDateString('en-US') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Planner Signed</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(agr.plannerSignature || '').replace(/[<>"]/g, '')} on ${agr.plannerSignedAt ? new Date(agr.plannerSignedAt).toLocaleDateString('en-US') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0">Status</td><td style="color:#527141;font-size:13px;font-weight:600;padding:4px 0;text-align:right">FULLY EXECUTED</td></tr>
      </table>
    </td></tr>
  </table>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">You can view the full agreement at any time in your <a href="https://rnb716events.com/Client/documents.html" style="color:#527141">Client Portal</a>.</p>
  <p style="color:#888;font-size:12px;line-height:1.6;margin:0">If you have any questions, please reach out to your event planner.</p>
</td></tr>
<tr><td style="background:#2d3a2d;padding:24px 30px;text-align:center">
  <p style="margin:0 0 6px;color:#b89a5e;font-size:12px;letter-spacing:1px">RNB EVENTS</p>
  <p style="margin:0;color:#a3b18a;font-size:11px">www.rnbevents716.com</p>
</td></tr>
</table>
</td></tr></table>
</body></html>`;

                    try {
                        await ses.send(new SendEmailCommand({
                            Source: RECOVERY_EMAIL,
                            Destination: { ToAddresses: [clientEmail.slice(0, 200)] },
                            Message: {
                                Subject: { Data: 'RNB Events - Your Agreement Has Been Fully Executed' },
                                Body: {
                                    Html: { Data: receiptHtml },
                                    Text: { Data: 'Dear ' + clientName + ',\n\nYour Event Planning Agreement has been fully signed by all parties.\n\nClient Signed: ' + (agr.coupleSignature || '') + ' on ' + (agr.coupleSignedAt || '') + '\nPlanner Signed: ' + (agr.plannerSignature || '') + ' on ' + (agr.plannerSignedAt || '') + '\n\nView your agreement: https://rnb716events.com/Client/documents.html\n\n- RNB Events' }
                                }
                            }
                        }));
                    } catch (emailErr) {
                        console.error('Failed to send agreement receipt:', emailErr);
                    }
                }

                /* Also create admin task as confirmation */
                createAdminTask({
                    id:         't' + Date.now(),
                    section:    'Client Portal',
                    task:       'Agreement fully executed for ' + clientName + (clientEmail ? ' — receipt sent to ' + clientEmail : ' — no email on file'),
                    priority:   'High',
                    status:     clientEmail ? 'Done' : 'Pending',
                    githubFile: ''
                });
            }

            return respond(200, { ok: true });
        }

        /* ── Branded booking email via SES ──────────── */
        if (path === '/send-booking-email') {
            const { email, fullName, eventType, eventDate, accessCode, plannerCode, teamCode } = body;
            if (!email || typeof email !== 'string') return respond(400, { ok: false, error: 'Missing email' });

            const portalUrl = 'https://rnb716events.com/Client';
            const htmlBody = `
<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">

<!-- Header -->
<tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,'Times New Roman',serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:8px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">Crafting Moments That Last Forever</p>
</td></tr>

<!-- Body -->
<tr><td style="padding:40px 30px">
  <h2 style="margin:0 0 20px;color:#2d3a2d;font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400">Welcome, ${String(fullName).replace(/[<>"]/g, '')}!</h2>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">We are thrilled to officially welcome you to the RNB Events family. Your${eventType ? ' <strong>' + String(eventType).replace(/[<>"]/g, '') + '</strong>' : ' event'}${eventDate ? ' on <strong>' + String(eventDate).replace(/[<>"]/g, '') + '</strong>' : ''} is going to be unforgettable.</p>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 24px">Your personalized client portal is ready. Use the access codes below to log in and start planning with your team.</p>

  <!-- Access Codes -->
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <p style="margin:0 0 12px;color:#527141;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:600">Your Access Codes</p>
      <table width="100%" cellpadding="6" cellspacing="0">
        <tr>
          <td style="color:#666;font-size:12px;letter-spacing:0.5px;padding:6px 0;border-bottom:1px solid #e0dcd4">COUPLE (Your Code)</td>
          <td style="color:#2d3a2d;font-size:16px;font-weight:600;font-family:monospace;padding:6px 0;border-bottom:1px solid #e0dcd4;text-align:right">${String(accessCode).replace(/[<>"]/g, '')}</td>
        </tr>
        ${plannerCode ? `<tr>
          <td style="color:#666;font-size:12px;letter-spacing:0.5px;padding:6px 0;border-bottom:1px solid #e0dcd4">PLANNER</td>
          <td style="color:#527141;font-size:16px;font-weight:600;font-family:monospace;padding:6px 0;border-bottom:1px solid #e0dcd4;text-align:right">${String(plannerCode).replace(/[<>"]/g, '')}</td>
        </tr>` : ''}
        ${teamCode ? `<tr>
          <td style="color:#666;font-size:12px;letter-spacing:0.5px;padding:6px 0">RNB TEAM</td>
          <td style="color:#2d3a2d;font-size:16px;font-weight:600;font-family:monospace;padding:6px 0;text-align:right">${String(teamCode).replace(/[<>"]/g, '')}</td>
        </tr>` : ''}
      </table>
    </td></tr>
  </table>

  <!-- CTA Button -->
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center" style="padding:10px 0 20px">
      <a href="${portalUrl}" style="display:inline-block;background:#527141;color:#fff;text-decoration:none;padding:14px 36px;border-radius:3px;font-size:12px;letter-spacing:2px;text-transform:uppercase;font-weight:500">ACCESS YOUR PORTAL</a>
    </td></tr>
  </table>

  <p style="color:#888;font-size:12px;line-height:1.6;margin:0">Keep these codes safe. Each code grants different access levels to your planning portal. Share the Planner code with your event coordinator only.</p>
</td></tr>

<!-- Footer -->
<tr><td style="background:#2d3a2d;padding:24px 30px;text-align:center">
  <p style="margin:0 0 6px;color:#b89a5e;font-size:12px;letter-spacing:1px">RNB EVENTS</p>
  <p style="margin:0;color:#a3b18a;font-size:11px">www.rnbevents716.com</p>
</td></tr>

</table>
</td></tr></table>
</body></html>`;

            const textBody = `Welcome, ${String(fullName)}!\n\nYour client portal is ready at ${portalUrl}\n\nAccess Codes:\n- Couple: ${accessCode}\n${plannerCode ? '- Planner: ' + plannerCode + '\n' : ''}${teamCode ? '- RNB Team: ' + teamCode + '\n' : ''}\nKeep these codes safe.\n\n- RNB Events\nwww.rnbevents716.com`;

            await ses.send(new SendEmailCommand({
                Source: RECOVERY_EMAIL,
                Destination: { ToAddresses: [String(email).slice(0, 200)] },
                Message: {
                    Subject: { Data: 'Welcome to RNB Events - Your Client Portal Access' },
                    Body: {
                        Html: { Data: htmlBody },
                        Text: { Data: textBody }
                    }
                }
            }));

            return respond(200, { ok: true });
        }

        /* ── Client: upload image file ───────────────── */
        if (path === '/upload-file') {
            const { codeHash, fileName, contentType, data } = body;
            if (!codeHash || typeof codeHash !== 'string') return respond(400, { ok: false, error: 'Missing codeHash' });
            if (!data || typeof data !== 'string') return respond(400, { ok: false, error: 'Missing file data' });

            const ALLOWED_TYPES = {
                'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif',
                'application/pdf': 'pdf',
                'application/msword': 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx'
            };
            const ext = ALLOWED_TYPES[(contentType || '').toLowerCase()];
            if (!ext) return respond(400, { ok: false, error: 'Only images (JPEG/PNG/WebP/GIF) or documents (PDF/DOC/DOCX) are allowed.' });

            const buf = Buffer.from(data, 'base64');
            if (buf.length > 15 * 1024 * 1024) return respond(400, { ok: false, error: 'File exceeds 15 MB limit.' });

            const clients = await readClients();
            const idx = findClientByAnyHash(clients, codeHash);
            if (idx === -1) return respond(404, { ok: false, error: 'Client not found' });

            const safeName = String(fileName || 'file').replace(/[^a-zA-Z0-9._-]/g, '_').replace(/\.[^.]+$/, '').slice(0, 80);
            const key = `client-uploads/${clients[idx].codeHash}/${Date.now()}-${safeName}.${ext}`;
            const mimeType = contentType.startsWith('image/') ? contentType : (ext === 'pdf' ? 'application/pdf' : ext === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : 'application/msword');

            await s3.send(new PutObjectCommand({
                Bucket: BUCKET,
                Key: key,
                Body: buf,
                ContentType: mimeType
            }));

            const fileUrl = `https://${BUCKET}.s3.us-east-2.amazonaws.com/${key}`;
            return respond(200, { ok: true, url: fileUrl });
        }

        /* ── Public quote request ─────────────────── */
        if (path === '/send-quote-request') {
            const { name, email, phone, location, eventType, eventDate, guestCount, budget, serviceScale, message } = body;
            if (!name  || typeof name  !== 'string') return respond(400, { ok: false, error: 'Name is required' });
            if (!email || typeof email !== 'string' || !/^[^@]+@[^@]+\.[^@]+$/.test(email))
                return respond(400, { ok: false, error: 'A valid email address is required' });

            const safe = s => String(s || '').replace(/[<>"]/g, '').slice(0, 500);

            const htmlBody = `
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">
<tr><td style="background:#2d3a2d;padding:36px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,serif;font-size:26px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:6px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">New Quote Request</p>
</td></tr>
<tr><td style="padding:36px 30px">
  <h2 style="margin:0 0 6px;color:#2d3a2d;font-family:Georgia,serif;font-size:20px;font-weight:400">Quote Request from ${safe(name)}</h2>
  <p style="margin:0 0 24px;color:#888;font-size:12px">${safe(email)}</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <table width="100%" cellpadding="5" cellspacing="0">
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Name</td><td style="color:#2d3a2d;font-size:13px;font-weight:600;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(name)}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Email</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(email)}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Phone</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(phone) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Location / City</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(location) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Event Type</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(eventType) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Event Date</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(eventDate) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Guest Count</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(guestCount) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Budget Range</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(budget) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:8px 0">Service Level</td><td style="color:#2d3a2d;font-size:13px;font-weight:600;padding:8px 0;text-align:right">${safe(serviceScale) || '—'}/10</td></tr>
      </table>
    </td></tr>
  </table>
  ${message ? `<p style="color:#666;font-size:11px;letter-spacing:1px;text-transform:uppercase;margin:0 0 8px">Message</p><p style="color:#3d3d3d;font-size:14px;line-height:1.7;background:#f9f7f4;padding:16px;border-radius:4px;margin:0 0 20px">${safe(message)}</p>` : ''}
  <p style="color:#888;font-size:12px">Received ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York', dateStyle: 'full', timeStyle: 'short' })} ET</p>
</td></tr>
<tr><td style="background:#2d3a2d;padding:20px 30px;text-align:center">
  <p style="margin:0;color:#a3b18a;font-size:11px">RNB Events &mdash; www.rnbevents716.com</p>
</td></tr>
</table></td></tr></table>
</body></html>`;

            await Promise.all([
                ses.send(new SendEmailCommand({
                    Source: RECOVERY_EMAIL,
                    Destination: { ToAddresses: [RECOVERY_EMAIL] },
                    ReplyToAddresses: [String(email).slice(0, 200)],
                    Message: {
                        Subject: { Data: `Quote Request: ${safe(name)} — ${safe(eventType) || 'Event'}` },
                        Body: {
                            Html: { Data: htmlBody },
                            Text: { Data: `New Quote Request\n\nName: ${safe(name)}\nEmail: ${safe(email)}\nPhone: ${safe(phone)}\nLocation: ${safe(location)}\nEvent: ${safe(eventType)}\nDate: ${safe(eventDate)}\nGuests: ${safe(guestCount)}\nBudget: ${safe(budget)}\nService Level: ${safe(serviceScale)}/10\n\nMessage:\n${safe(message)}` }
                        }
                    }
                })),
                createAdminProspect({
                    id:        'lead_' + Date.now(),
                    name:      safe(name),
                    email:     safe(email),
                    phone:     safe(phone) || '',
                    eventType: safe(eventType) || '',
                    eventDate: safe(eventDate) || '',
                    status:    'New Lead',
                    notes:     'Website quote request.' +
                               (budget      ? ' Budget: '         + safe(budget)      : '') +
                               (location    ? ' Location: '       + safe(location)    : '') +
                               (guestCount  ? ' Guests: '         + safe(guestCount)  : '') +
                               (serviceScale? ' Service Level: '  + safe(serviceScale) + '/10' : '') +
                               (message     ? ' Message: '        + safe(message)     : ''),
                    added:     new Date().toISOString().slice(0, 10)
                }).catch(e => console.error('Prospect registration failed:', e))
            ]);

            return respond(200, { ok: true });
        }

        /* ── Admin password reset via email ─────────── */
        if (path === '/send-reset-code') {
            const { action, code } = body;

            if (action === 'send') {
                const pin = String(Math.floor(100000 + Math.random() * 900000));
                const expiry = Date.now() + 10 * 60 * 1000; /* 10 min */
                await s3.send(new PutObjectCommand({
                    Bucket: BUCKET,
                    Key: RESET_CODE_KEY,
                    Body: JSON.stringify({ code: pin, expiry }),
                    ContentType: 'application/json'
                }));

                await ses.send(new SendEmailCommand({
                    Source: RECOVERY_EMAIL,
                    Destination: { ToAddresses: [RECOVERY_EMAIL] },
                    Message: {
                        Subject: { Data: 'RNB Events Admin - Password Reset Code' },
                        Body: {
                            Text: { Data: 'Your admin password reset code is: ' + pin + '\n\nThis code expires in 10 minutes.\n\nIf you did not request this, ignore this email.' }
                        }
                    }
                }));

                return respond(200, { ok: true });
            }

            if (action === 'verify') {
                if (!code || typeof code !== 'string') return respond(400, { ok: false, error: 'Missing code' });

                let stored;
                try {
                    const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: RESET_CODE_KEY }));
                    stored = JSON.parse(await res.Body.transformToString());
                } catch (e) {
                    return respond(400, { ok: false, error: 'No reset code pending.' });
                }

                if (!stored || Date.now() > stored.expiry) {
                    return respond(400, { ok: false, error: 'Code expired. Request a new one.' });
                }
                if (code !== stored.code) {
                    return respond(400, { ok: false, error: 'Invalid code.' });
                }

                /* Clean up used code */
                try {
                    await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: RESET_CODE_KEY }));
                } catch (e) {}

                return respond(200, { ok: true });
            }

            return respond(400, { ok: false, error: 'Invalid action' });
        }

        /* ── Analytics: log a page view to S3 ─────── */
        if (path === '/track-visit') {
            const VALID_SECTIONS = ['public', 'admin', 'client', 'prospect'];
            const VALID_TYPES    = ['page_view', 'click'];
            const section  = VALID_SECTIONS.includes(body.section) ? body.section : 'public';
            const entryType = VALID_TYPES.includes(body.type) ? body.type : 'page_view';

            const sourceIp = (event.requestContext && event.requestContext.http)
                ? (event.requestContext.http.sourceIp || '')
                : '';

            const dateKey = new Date().toISOString().slice(0, 10);
            const s3Key   = `logs/visits-${dateKey}.ndjson`;

            /* Run geo lookup and S3 read in parallel */
            const [geo, existingContent] = await Promise.all([
                geoLookup(sourceIp),
                s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: s3Key }))
                    .then(r => r.Body.transformToString())
                    .catch(() => '')
            ]);

            const entry = {
                ts:          new Date().toISOString(),
                section,
                type:        entryType,
                action:      entryType === 'click' ? String(body.action || '').slice(0, 100) : '',
                page:        String(body.page        || '').slice(0, 500),
                title:       String(body.title       || '').slice(0, 500),
                referrer:    String(body.referrer    || '').slice(0, 2000),
                utmSource:   String(body.utmSource   || '').slice(0, 200),
                utmMedium:   String(body.utmMedium   || '').slice(0, 200),
                utmCampaign: String(body.utmCampaign || '').slice(0, 200),
                utmTerm:     String(body.utmTerm     || '').slice(0, 500),
                sessionId:   String(body.sessionId   || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64),
                codeHash:    section === 'public' ? '' : String(body.codeHash || '').slice(0, 100),
                loadMs:      entryType === 'page_view' && Number.isFinite(body.loadMs) ? Math.round(body.loadMs) : null,
                city:        geo.city,
                country:     geo.country
            };

            await s3.send(new PutObjectCommand({
                Bucket: BUCKET, Key: s3Key,
                Body: existingContent + JSON.stringify(entry) + '\n',
                ContentType: 'application/x-ndjson',
                CacheControl: 'no-cache, no-store, must-revalidate'
            }));

            return respond(200, { ok: true });
        }

        return respond(404, { ok: false, error: 'Unknown route' });
    } catch (err) {
        console.error(err);
        return respond(500, { ok: false, error: err.message });
    }
};
