const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { SESClient, SendEmailCommand, SendRawEmailCommand } = require('@aws-sdk/client-ses');
const PDFDocument = require('pdfkit');
const s3 = new S3Client({ region: 'us-east-2' });
const ses = new SESClient({ region: 'us-east-2' });

const BUCKET = 'rnbevents716';
const KEY = 'clients.json';
const ADMIN_DATA_KEY = 'admin-data.json';
const RECOVERY_EMAIL = 'rnbevents716@gmail.com';  // admin notification TO address
const FROM_EMAIL     = 'info@rnbevents716.com';   // all SES sends come FROM this (DKIM-verified domain)
const INFO_EMAIL     = 'info@rnbevents716.com';   // BCC copy
const RESET_CODE_KEY = 'admin-reset-code.json';
const HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Content-Type': 'application/json'
};

function respond(code, data) {
    return { statusCode: code, headers: HEADERS, body: JSON.stringify(data) };
}

/* ── PDF quote generator ─────────────────────────────────────────── */
function generateQuotePDF(opts) {
    return new Promise(function (resolve, reject) {
        var doc  = new PDFDocument({ margin: 0, size: 'LETTER' });
        var bufs = [];
        doc.on('data', function (c) { bufs.push(c); });
        doc.on('end',  function ()  { resolve(Buffer.concat(bufs)); });
        doc.on('error', reject);

        var W       = doc.page.width;   // 612
        var gold    = '#b89a5e';
        var dkGn    = '#2d3a2d';
        var mdGn    = '#527141';
        var gray    = '#888888';
        var body    = '#3d3d3d';
        var divider = '#e8e2d9';
        var M       = 50;

        /* Header bar */
        doc.rect(0, 0, W, 90).fill(dkGn);
        doc.fillColor(gold).font('Helvetica-Bold').fontSize(24).text('RNB EVENTS', M, 22);
        doc.fillColor('#a3b18a').font('Helvetica').fontSize(9).text('EVENT PLANNING & COORDINATION', M, 54);
        doc.fillColor('#a3b18a').font('Helvetica').fontSize(9)
           .text(new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
                 0, 38, { align: 'right', width: W - M });

        /* Intro */
        doc.fillColor(mdGn).font('Helvetica').fontSize(8).text('PERSONALIZED QUOTE', M, 110);
        doc.fillColor(dkGn).font('Helvetica-Bold').fontSize(20).text('Hello, ' + opts.name, M, 126);

        var y = 162;

        /* Package badge */
        var badgeColor = (opts.pkgData && opts.pkgData.color) || dkGn;
        doc.roundedRect(M, y, 240, 22, 11).fill(badgeColor);
        doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(9)
           .text(opts.pkg + '  \u2014  ' + ((opts.pkgData && opts.pkgData.tagline) || ''), M + 10, y + 7, { width: 220 });
        y += 32;

        /* Event info */
        if (opts.eventType || opts.eventDate) {
            doc.fillColor(gray).font('Helvetica').fontSize(10)
               .text((opts.eventType || 'Event') + (opts.eventDate ? '  |  ' + opts.eventDate : ''), M, y);
            y = doc.y + 4;
        }

        /* Package description */
        doc.fillColor(body).font('Helvetica').fontSize(10)
           .text((opts.pkgData && opts.pkgData.desc) || '', M, y, { width: W - 2 * M, lineGap: 2 });
        y = doc.y + 16;

        /* Divider */
        doc.moveTo(M, y).lineTo(W - M, y).strokeColor(divider).lineWidth(1).stroke();
        y += 14;

        /* Table header */
        var COL_D = M;
        var COL_Q = M + 280;
        var COL_U = M + 330;
        var COL_A = M + 420;
        var CW_D  = 270;
        var CW_Q  = 45;
        var CW_U  = 85;
        var CW_A  = W - M - COL_A;

        doc.rect(M, y - 3, W - 2 * M, 20).fill('#f5f2ec');
        doc.fillColor(mdGn).font('Helvetica-Bold').fontSize(8)
           .text('DESCRIPTION', COL_D, y + 3, { width: CW_D })
           .text('QTY',         COL_Q, y + 3, { width: CW_Q, align: 'right' })
           .text('UNIT PRICE',  COL_U, y + 3, { width: CW_U, align: 'right' })
           .text('AMOUNT',      COL_A, y + 3, { width: CW_A, align: 'right' });
        y += 22;

        doc.moveTo(M, y).lineTo(W - M, y).strokeColor(dkGn).lineWidth(1.5).stroke();
        y += 8;

        /* Line items */
        var fmt = function (n) {
            var abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            return (n < 0 ? '(' : '') + '$' + abs + (n < 0 ? ')' : '');
        };

        opts.items.forEach(function (item) {
            var sub   = item.qty * item.price;
            var isNeg = sub < 0;

            var preY = y;
            doc.fillColor(body).font('Helvetica').fontSize(10)
               .text(item.description, COL_D, y, { width: CW_D });
            var afterDescY = doc.y;
            var rowH = Math.max(afterDescY - preY, 14) + 4;

            doc.fillColor(isNeg ? '#c0392b' : body).font('Helvetica').fontSize(10)
               .text(String(item.qty),                       COL_Q, y, { width: CW_Q, align: 'right' })
               .text(item.price !== 0 ? fmt(item.price) : '\u2014', COL_U, y, { width: CW_U, align: 'right' })
               .text(sub !== 0 ? fmt(sub) : '\u2014',        COL_A, y, { width: CW_A, align: 'right' });

            y += rowH;
            doc.moveTo(M, y).lineTo(W - M, y).strokeColor(divider).lineWidth(0.5).stroke();
            y += 5;
        });

        /* Grand total / breakdown */
        y += 8;
        doc.moveTo(M, y).lineTo(W - M, y).strokeColor(divider).lineWidth(0.5).stroke();
        y += 8;

        if (opts.discountPct || opts.laborProduction || opts.taxAmt) {
            /* New breakdown format */
            var rowItems = [];
            if (opts.discountPct > 0) rowItems.push({ label: 'Items Subtotal', val: opts.itemsSubtotal || 0, color: gray });
            if (opts.discountPct > 0) rowItems.push({ label: 'Discount (' + opts.discountPct + '%)', val: -(opts.discountAmt || 0), color: '#c0392b' });
            if (opts.laborProduction > 0) rowItems.push({ label: 'Labor Production', val: opts.laborProduction, color: body });
            if (opts.taxAmt > 0) rowItems.push({ label: 'Texas Sales Tax (8.25%)', val: opts.taxAmt, color: gray });
            if (opts.deposit > 0) rowItems.push({ label: 'Required Deposit', val: opts.deposit, color: '#527141' });

            rowItems.forEach(function (r) {
                doc.fillColor(r.color).font('Helvetica').fontSize(9)
                   .text(r.label, M, y, { width: W - 2 * M - CW_A })
                   .text((r.val < 0 ? '-' : '') + '$' + Math.abs(r.val).toLocaleString('en-US', { minimumFractionDigits: 2 }), 0, y, { align: 'right', width: W - M });
                y = doc.y + 4;
            });

            doc.moveTo(M, y).lineTo(W - M, y).strokeColor(dkGn).lineWidth(1.5).stroke();
            y += 8;
            doc.fillColor(gray).font('Helvetica').fontSize(9)
               .text('GRAND TOTAL', M, y, { width: W - 2 * M - CW_A, align: 'right' });
            if (opts.grandTotal !== 0) {
                doc.fillColor(gold).font('Helvetica-Bold').fontSize(18)
                   .text(fmt(opts.grandTotal), 0, y - 4, { align: 'right', width: W - M });
            }
        } else {
            /* Legacy simple total */
            doc.fillColor(gray).font('Helvetica').fontSize(9)
               .text('ESTIMATED TOTAL', M, y, { width: W - 2 * M - CW_A, align: 'right' });
            if (opts.grandTotal !== 0) {
                doc.fillColor(gold).font('Helvetica-Bold').fontSize(18)
                   .text(fmt(opts.grandTotal), 0, y - 4, { align: 'right', width: W - M });
            }
        }
        y = doc.y + 16;

        /* Personal note */
        if (opts.customNote) {
            doc.moveTo(M, y).lineTo(W - M, y).strokeColor(divider).lineWidth(1).stroke();
            y += 12;
            doc.fillColor(gray).font('Helvetica').fontSize(8).text('A NOTE FROM OUR TEAM', M, y);
            y += 14;
            doc.fillColor(body).font('Helvetica').fontSize(10)
               .text(opts.customNote, M, y, { width: W - 2 * M, lineGap: 2 });
            y = doc.y + 12;
        }

        /* Disclaimer */
        if (y < doc.page.height - 120) {
            doc.moveTo(M, y).lineTo(W - M, y).strokeColor(divider).lineWidth(0.5).stroke();
            y += 10;
            doc.fillColor('#aaaaaa').font('Helvetica-Oblique').fontSize(8)
               .text('* All estimates are based on preliminary planning details and are subject to review during your consultation. Final pricing will be confirmed in your event agreement.',
                     M, y, { width: W - 2 * M, lineGap: 2 });
        }

        /* Footer */
        var fY = doc.page.height - 50;
        doc.rect(0, fY, W, 50).fill(dkGn);
        doc.fillColor('#a3b18a').font('Helvetica').fontSize(9)
           .text('RNB Events Production & Coordination LLC', 0, fY + 10, { align: 'center', width: W });
        doc.fillColor(mdGn).font('Helvetica').fontSize(8)
           .text('info@rnbevents716.com  \u00b7  rnbevents716.com', 0, fY + 26, { align: 'center', width: W });
        doc.fillColor(mdGn).font('Helvetica').fontSize(7)
           .text('Powered by ynk-techusa.com', 0, fY + 38, { align: 'center', width: W });

        doc.end();
    });
}

/* ── Raw MIME email builder (supports PDF attachment) ─────────────── */
function buildRawEmail(to, subject, htmlBody, plainBody, pdfBuf, pdfFilename, bcc) {
    var mix = 'RNBmix' + Date.now();
    var alt = 'RNBalt' + Date.now();
    var b64 = function (s) {
        return Buffer.from(s, 'utf-8').toString('base64').match(/.{1,76}/g).join('\r\n');
    };
    var lines = [
        'From: RNB Events <' + FROM_EMAIL + '>',
        'To: ' + to,
        bcc ? 'Bcc: ' + bcc : null,
        'Subject: ' + subject,
        'MIME-Version: 1.0',
        'Content-Type: multipart/mixed; boundary="' + mix + '"',
        '',
        '--' + mix,
        'Content-Type: multipart/alternative; boundary="' + alt + '"',
        '',
        '--' + alt,
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
        '',
        b64(plainBody),
        '',
        '--' + alt,
        'Content-Type: text/html; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
        '',
        b64(htmlBody),
        '',
        '--' + alt + '--',
        '',
        '--' + mix,
        'Content-Type: application/pdf',
        'Content-Transfer-Encoding: base64',
        'Content-Disposition: attachment; filename="' + pdfFilename + '"',
        '',
        pdfBuf.toString('base64').match(/.{1,76}/g).join('\r\n'),
        '',
        '--' + mix + '--'
    ];
    return Buffer.from(lines.filter(function(l){ return l !== null; }).join('\r\n'), 'utf-8');
}


async function readClients() {
    const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: KEY }));
    const text = await res.Body.transformToString();
    return JSON.parse(text);
}

async function writeClients(clients) {
    await s3.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: KEY,
        Body: JSON.stringify(clients),
        ContentType: 'application/json',
        CacheControl: 'no-cache, no-store, must-revalidate'
    }));
}

/* ── Section sanitizers ─────────────────────────── */

function sanitizeUrl(url) {
    url = String(url || '').slice(0, 2000);
    return /^https?:\/\//i.test(url) ? url : '';
}

/* Accepts https:// URLs and data: image URIs (device uploads) */
function sanitizeImageSrc(src) {
    src = String(src || '');
    if (/^https?:\/\//i.test(src)) return src.slice(0, 3000);
    if (/^data:image\/(jpeg|png|webp|gif);base64,/.test(src)) return src.slice(0, 200000);
    return '';
}

function sanitizeTimeline(data) {
    if (!Array.isArray(data)) return [];
    const STATUSES = ['upcoming', 'in-progress', 'done'];
    return data.slice(0, 50).map(item => ({
        date: String(item.date || '').slice(0, 100),
        milestone: String(item.milestone || '').slice(0, 200),
        notes: String(item.notes || '').slice(0, 500),
        status: STATUSES.includes(item.status) ? item.status : 'upcoming'
    })).filter(item => item.milestone.trim());
}

function sanitizeVendors(data) {
    if (!Array.isArray(data)) return [];
    return data.slice(0, 30).map(item => ({
        name: String(item.name || '').slice(0, 200),
        role: String(item.role || '').slice(0, 100),
        phone: String(item.phone || '').replace(/[^\d\s\-\+\(\)]/g, '').slice(0, 30),
        email: String(item.email || '').slice(0, 200),
        status: String(item.status || 'TBD').slice(0, 50)
    })).filter(item => item.name.trim());
}

function sanitizeDocuments(data) {
    if (!Array.isArray(data)) return [];
    return data.slice(0, 50).map(item => ({
        name: String(item.name || '').slice(0, 200),
        type: String(item.type || 'Document').slice(0, 100),
        url: sanitizeUrl(item.url),
        date: String(item.date || '').slice(0, 50)
    })).filter(item => item.name.trim() && item.url);
}

function sanitizeGallery(data) {
    if (!Array.isArray(data)) return [];
    return data.slice(0, 100).map(item => {
        if (typeof item === 'string') return { url: sanitizeImageSrc(item), caption: '' };
        return {
            url: sanitizeImageSrc(String(item.url || '')),
            caption: String(item.caption || '').slice(0, 300)
        };
    }).filter(item => item.url);
}

function sanitizeMoodboard(data) {
    if (!data || typeof data !== 'object') return { palette: [], images: [], description: '' };
    return {
        description: String(data.description || '').slice(0, 2000),
        palette: Array.isArray(data.palette)
            ? data.palette.slice(0, 20).map(hex => String(hex).replace(/[^#a-fA-F0-9]/g, '').slice(0, 10))
            : [],
        images: Array.isArray(data.images)
            ? data.images.slice(0, 50).map(img => {
                if (typeof img === 'string') return { url: sanitizeImageSrc(img), caption: '' };
                return { url: sanitizeImageSrc(String(img.url || '')), caption: String(img.caption || '').slice(0, 300) };
            }).filter(img => img.url)
            : []
    };
}

function sanitizeAgreement(data) {
    if (!data || typeof data !== 'object') return { status: 'pending', coupleSignature: '', coupleSignedAt: '', plannerSignature: '', plannerSignedAt: '', coupleSignatureIp: '', coupleSignatureUserAgent: '', attachments: [] };
    const STATUSES = ['pending', 'couple-signed', 'fully-executed'];
    return {
        status:                   STATUSES.includes(data.status) ? data.status : 'pending',
        coupleSignature:          String(data.coupleSignature          || '').slice(0, 300),
        coupleSignedAt:           String(data.coupleSignedAt           || '').slice(0, 50),
        coupleSignatureIp:        String(data.coupleSignatureIp        || '').slice(0, 100),
        coupleSignatureUserAgent: String(data.coupleSignatureUserAgent || '').slice(0, 500),
        plannerSignature:         String(data.plannerSignature         || '').slice(0, 300),
        plannerSignedAt:          String(data.plannerSignedAt          || '').slice(0, 50),
        attachments: Array.isArray(data.attachments) ? data.attachments.slice(0, 20).map(a => ({
            name:       String(a.name       || '').slice(0, 200),
            url:        sanitizeUrl(a.url),
            uploadedAt: String(a.uploadedAt || '').slice(0, 50),
            caption:    String(a.caption    || '').slice(0, 300)
        })).filter(a => a.url) : []
    };
}

const SECTION_SANITIZERS = {
    timeline: sanitizeTimeline,
    vendors: sanitizeVendors,
    documents: sanitizeDocuments,
    gallery: sanitizeGallery,
    moodboard: sanitizeMoodboard,
    agreement: sanitizeAgreement
};

/* ── Find client by any of 3 access hashes ──────── */
function findClientByAnyHash(clients, hash) {
    return clients.findIndex(c =>
        c.codeHash === hash ||
        c.plannerCodeHash === hash ||
        c.teamCodeHash === hash
    );
}

/* ── Append an entry to the client's editLog ─────── */
function appendEditLog(client, entry) {
    const ROLES = ['couple', 'planner', 'rnbTeam'];
    if (!client.editLog) client.editLog = [];
    client.editLog = client.editLog.slice(-49);
    client.editLog.push({
        ts:       String(entry.ts       || new Date().toISOString()).slice(0, 50),
        role:     ROLES.includes(entry.role) ? entry.role : 'unknown',
        roleName: String(entry.roleName || '').slice(0, 100),
        action:   String(entry.action   || '').slice(0, 200)
    });
}

/* ── Admin CRM data (S3) ───────────────────────── */
async function readAdminData() {
    try {
        const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: ADMIN_DATA_KEY }));
        const text = await res.Body.transformToString();
        return JSON.parse(text);
    } catch (e) {
        // NoSuchKey on first use — return empty structure
        return { prospects: [], tasks: [], content: {}, adminCodeHash: '' };
    }
}

async function writeAdminData(data) {
    await s3.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: ADMIN_DATA_KEY,
        Body: JSON.stringify(data),
        ContentType: 'application/json',
        CacheControl: 'no-cache, no-store, must-revalidate'
    }));
}

/* ── Create admin task via S3 ─────────────────── */
async function createAdminTask(taskObj) {
    try {
        const data = await readAdminData();
        const tasks = Array.isArray(data.tasks) ? data.tasks : [];
        tasks.unshift(taskObj);
        await writeAdminData({ ...data, tasks });
    } catch (e) {
        console.error('Failed to create admin task:', e);
    }
}

/* ── Register a new lead/prospect in Admin CRM ── */
async function createAdminProspect(prospectObj) {
    try {
        const data = await readAdminData();
        const prospects = Array.isArray(data.prospects) ? data.prospects : [];
        prospects.unshift(prospectObj);
        await writeAdminData({ ...data, prospects });
    } catch (e) {
        console.error('Failed to register prospect:', e);
    }
}

/* ── IP geolocation (ip-api.com free tier) ───── */
async function geoLookup(ip) {
    if (!ip || ip === '127.0.0.1' || ip === '::1') return { city: '', country: '' };
    try {
        const res = await fetch(`http://ip-api.com/json/${ip}?fields=city,country`, {
            signal: AbortSignal.timeout(1500)
        });
        if (!res.ok) return { city: '', country: '' };
        const data = await res.json();
        return {
            city:    String(data.city    || '').slice(0, 100),
            country: String(data.country || '').slice(0, 100)
        };
    } catch (e) {
        return { city: '', country: '' };
    }
}

exports.handler = async (event) => {
    if (event.requestContext && event.requestContext.http && event.requestContext.http.method === 'OPTIONS') {
        return respond(200, '');
    }

    const path = (event.rawPath || event.requestContext.http.path || '').replace(/\/$/, '');
    const method = (event.requestContext?.http?.method || 'POST').toUpperCase();

    try {
        const body = JSON.parse(event.body || '{}');

        /* ── Admin data: GET all (replaces Google Apps Script) ── */
        if (path === '/admin-data' && body.action === 'get') {
            const data = await readAdminData();
            return respond(200, data);
        }

        /* ── Admin data: POST/save (replaces Google Apps Script) ── */
        if (path === '/admin-data' && method === 'POST') {
            const current = await readAdminData();
            // Merge: only update keys that are present in body
            const updated = { ...current };
            if (Array.isArray(body.prospects))    updated.prospects     = body.prospects;
            if (Array.isArray(body.tasks))         updated.tasks         = body.tasks;
            if (body.content && typeof body.content === 'object') {
                updated.content = { ...(current.content || {}), ...body.content };
            }
            if (typeof body.adminCodeHash === 'string') updated.adminCodeHash = body.adminCodeHash;
            await writeAdminData(updated);
            return respond(200, { ok: true, ts: new Date().toISOString() });
        }

        /* ── Admin: full publish ────────────────────── */
        if (path === '/upload-clients') {
            if (!body.clients || !Array.isArray(body.clients)) {
                return respond(400, { ok: false, error: 'Missing clients array' });
            }

            /* Merge: admin controls basic fields + deletions; S3 owns portal section data.
               - Clients absent from incoming list are DELETED (that's the fix).
               - For kept clients, preserve portal sections from S3 so in-progress
                 portal work is never overwritten by a stale admin session. */
            const PORTAL_SECTIONS = ['timeline','vendors','documents','gallery','moodboard','agreement','editLog','trackingNotes'];
            let existing = [];
            try { existing = await readClients(); } catch (e) { /* first write */ }
            if (!Array.isArray(existing)) existing = [];

            const existingById = {};
            existing.forEach(c => { if (c && c.id) existingById[c.id] = c; });

            const merged = body.clients.map(incoming => {
                const s3 = existingById[incoming.id];
                if (!s3) return incoming; // new client
                // Merge: take admin fields from incoming, portal sections from S3
                const out = Object.assign({}, incoming);
                PORTAL_SECTIONS.forEach(k => { if (s3[k] !== undefined) out[k] = s3[k]; });
                return out;
            });
            // Clients not in incoming are simply omitted — that's the delete

            await writeClients(merged);
            return respond(200, { ok: true, count: merged.length });
        }

        /* ── Client: update own tracking notes ──────── */
        if (path === '/update-client-notes') {
            const { codeHash, clientTodos, plannerTodos, teamTodos, editLogEntry } = body;
            if (!codeHash || typeof codeHash !== 'string') return respond(400, { ok: false, error: 'Missing codeHash' });

            const ALLOWED = ['pending', 'in-progress', 'done', 'not-applicable'];
            const ROLES   = ['couple', 'planner', 'rnbTeam'];

            function sanitizeTodoList(arr) {
                if (!Array.isArray(arr)) return null;
                return arr.slice(0, 100).map(item => {
                    const out = {
                        text:   String(item.text   || '').slice(0, 500),
                        status: ALLOWED.includes(item.status) ? item.status : 'pending'
                    };
                    if (item.addedAt)  out.addedAt  = String(item.addedAt).slice(0, 50);
                    if (item.addedBy && ROLES.includes(item.addedBy)) out.addedBy = item.addedBy;
                    return out;
                }).filter(item => item.text.trim().length > 0);
            }

            const cleanClientTodos  = clientTodos  !== undefined ? sanitizeTodoList(clientTodos)  : undefined;
            const cleanPlannerTodos = plannerTodos  !== undefined ? sanitizeTodoList(plannerTodos) : undefined;
            const cleanTeamTodos    = teamTodos     !== undefined ? sanitizeTodoList(teamTodos)    : undefined;

            if (clientTodos !== undefined && cleanClientTodos === null)
                return respond(400, { ok: false, error: 'clientTodos must be an array' });

            const clients = await readClients();
            const idx = findClientByAnyHash(clients, codeHash);
            if (idx === -1) return respond(404, { ok: false, error: 'Client not found' });

            if (!clients[idx].trackingNotes) clients[idx].trackingNotes = {};
            if (cleanClientTodos  !== undefined && cleanClientTodos  !== null) clients[idx].trackingNotes.clientTodos  = cleanClientTodos;
            if (cleanPlannerTodos !== undefined && cleanPlannerTodos !== null) clients[idx].trackingNotes.plannerTodos = cleanPlannerTodos;
            if (cleanTeamTodos    !== undefined && cleanTeamTodos    !== null) clients[idx].trackingNotes.teamTodos    = cleanTeamTodos;

            if (editLogEntry && typeof editLogEntry === 'object') {
                appendEditLog(clients[idx], editLogEntry);
            }

            await writeClients(clients);
            return respond(200, { ok: true });
        }

        /* ── Client: update any portal section ──────── */
        if (path === '/update-client-section') {
            const { codeHash, section, data, editLogEntry } = body;
            if (!codeHash || typeof codeHash !== 'string') return respond(400, { ok: false, error: 'Missing codeHash' });
            if (!SECTION_SANITIZERS[section]) return respond(400, { ok: false, error: 'Invalid section: ' + section });

            const clients = await readClients();
            const idx = findClientByAnyHash(clients, codeHash);
            if (idx === -1) return respond(404, { ok: false, error: 'Client not found' });

            const oldAgreementStatus = (clients[idx].agreement || {}).status;
            clients[idx][section] = SECTION_SANITIZERS[section](data);

            /* For agreement: capture IP + userAgent server-side when couple signs for the first time */
            if (section === 'agreement' && clients[idx].agreement.status === 'couple-signed' && oldAgreementStatus === 'pending') {
                const sigIp = (event.requestContext && event.requestContext.http && event.requestContext.http.sourceIp)
                    ? event.requestContext.http.sourceIp
                    : ((event.headers && (event.headers['x-forwarded-for'] || event.headers['X-Forwarded-For']))
                        ? (event.headers['x-forwarded-for'] || event.headers['X-Forwarded-For']).split(',')[0].trim()
                        : 'Unknown');
                clients[idx].agreement.coupleSignatureIp        = sigIp.slice(0, 100);
                clients[idx].agreement.coupleSignatureUserAgent = String(body.coupleSignatureUserAgent || '').slice(0, 500);
            }

            if (editLogEntry && typeof editLogEntry === 'object') {
                appendEditLog(clients[idx], editLogEntry);
            }

            await writeClients(clients);

            /* Send confirmation email to client immediately when they sign (couple-signed transition) */
            if (section === 'agreement' && clients[idx].agreement.status === 'couple-signed' && oldAgreementStatus === 'pending') {
                const c = clients[idx];
                const clientEmail = c.email || '';
                const clientName  = c.fullName || c.firstName || 'Client';
                const agr         = c.agreement;
                if (clientEmail) {
                    const confirmHtml = `
<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">
<tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,'Times New Roman',serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:8px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">Crafting Moments That Last Forever</p>
</td></tr>
<tr><td style="padding:40px 30px">
  <h2 style="margin:0 0 20px;color:#2d3a2d;font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400">Agreement Signed — Awaiting Countersignature</h2>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">Dear ${clientName.replace(/[<>"]/g, '')},</p>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">This email confirms that you have signed the <strong>Event Vendor Agreement</strong> with RNB Events. Your signature has been recorded and the agreement is now awaiting countersignature from your Vendor.</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <p style="margin:0 0 12px;color:#527141;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:600">Signature Details</p>
      <table width="100%" cellpadding="4" cellspacing="0">
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Name Signed</td><td style="color:#2d3a2d;font-size:13px;font-weight:600;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(agr.coupleSignature || '').replace(/[<>"]/g, '')}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Date &amp; Time</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${agr.coupleSignedAt ? new Date(agr.coupleSignedAt).toLocaleString('en-US', { dateStyle: 'long', timeStyle: 'short' }) : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Event</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(c.eventType || 'Event').replace(/[<>"]/g, '')}${c.eventDate ? ' — ' + c.eventDate.replace(/[<>"]/g, '') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0">Status</td><td style="color:#b89a5e;font-size:13px;font-weight:600;padding:4px 0;text-align:right">AWAITING COUNTERSIGNATURE</td></tr>
      </table>
    </td></tr>
  </table>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">You will receive another email once RNB Events countersigns the agreement.</p>
  <p style="color:#888;font-size:12px;line-height:1.6;margin:0 0 16px">If you did not authorize this signature, please contact us immediately at <a href="mailto:rnbevents716@gmail.com" style="color:#527141">rnbevents716@gmail.com</a>.</p>
  <p style="color:#aaa;font-size:11px;line-height:1.6;margin:0">Device: ${(agr.coupleSignatureUserAgent || 'Unknown').replace(/[<>"]/g, '').slice(0, 120)}</p>
</td></tr>
<tr><td style="background:#2d3a2d;padding:24px 30px;text-align:center">
  <p style="margin:0 0 6px;color:#b89a5e;font-size:12px;letter-spacing:1px">RNB EVENTS</p>
  <p style="margin:0;color:#a3b18a;font-size:11px">www.rnbevents716.com</p>
</td></tr>
</table>
</td></tr></table>
</body></html>`;
                    try {
                        await ses.send(new SendEmailCommand({
                            Source: FROM_EMAIL,
                            Destination: { ToAddresses: [clientEmail.slice(0, 200)] },
                            Message: {
                                Subject: { Data: 'RNB Events — You Have Signed the Agreement (Awaiting Countersignature)' },
                                Body: {
                                    Html: { Data: confirmHtml },
                                    Text: { Data: `Dear ${clientName},\n\nThis confirms you have signed the Event Vendor Agreement with RNB Events.\n\nName Signed: ${agr.coupleSignature || ''}\nDate: ${agr.coupleSignedAt || ''}\nEvent: ${c.eventType || 'Event'}${c.eventDate ? ' \u2014 ' + c.eventDate : ''}\nStatus: Awaiting countersignature\n\nIf you did not authorize this signature, contact us immediately at rnbevents716@gmail.com.\n\n- RNB Events\nwww.rnbevents716.com` }
                                }
                            }
                        }));
                    } catch (emailErr) {
                        console.error('Failed to send signing confirmation email:', emailErr);
                    }
                }
                /* Also notify planner that client has signed and countersignature is required */
                const plannerAlertEmail = (c.plannerEmail || '').trim();
                if (plannerAlertEmail && plannerAlertEmail !== RECOVERY_EMAIL) {
                    try {
                        await ses.send(new SendEmailCommand({
                            Source: FROM_EMAIL,
                            Destination: { ToAddresses: [plannerAlertEmail.slice(0, 200)] },
                            Message: {
                                Subject: { Data: `RNB Events \u2014 ${(c.fullName || c.firstName || 'Your Client').replace(/[<>"]/g, '')} Has Signed — Countersignature Required` },
                                Body: {
                                    Html: { Data: `<html><body style="font-family:'Helvetica Neue',Arial,sans-serif;color:#2d3a2d"><div style="max-width:600px;margin:0 auto;padding:40px 20px"><h2 style="color:#2d3a2d">Countersignature Required</h2><p>${(c.fullName || c.firstName || 'Your client').replace(/[<>"]/g, '')} has signed the Event Vendor Agreement.</p><p><strong>Signed:</strong> ${(agr.coupleSignature || '').replace(/[<>"]/g, '')} &mdash; ${agr.coupleSignedAt ? new Date(agr.coupleSignedAt).toLocaleString('en-US') : ''}</p><p><strong>Event:</strong> ${(c.eventType || '').replace(/[<>"]/g, '')}${c.eventDate ? ' &mdash; ' + c.eventDate.replace(/[<>"]/g, '') : ''}</p><p>Please log in to the RNB Events portal and countersign the agreement to fully execute the contract.</p><p><a href="https://rnb716events.com/Client/documents.html">Go to Client Portal &rarr;</a></p><hr style="border:none;border-top:1px solid #e0dcd4"><p style="font-size:12px;color:#888">RNB Events &mdash; www.rnbevents716.com</p></div></body></html>` },
                                    Text: { Data: `${(c.fullName || 'Your client')} has signed the Event Vendor Agreement and countersignature is required.\n\nSigned: ${agr.coupleSignature || ''} on ${agr.coupleSignedAt || ''}\nEvent: ${c.eventType || ''}${c.eventDate ? ' \u2014 ' + c.eventDate : ''}\n\nLog in to countersign: https://rnb716events.com/Client/documents.html\n\n- RNB Events` }
                                }
                            }
                        }));
                    } catch (plannerAlertErr) {
                        console.error('Failed to send planner countersign alert:', plannerAlertErr);
                    }
                }
            }

            /* Auto-send receipt + create admin task when agreement becomes fully-executed */
            if (section === 'agreement' && clients[idx].agreement.status === 'fully-executed' && oldAgreementStatus !== 'fully-executed') {
                const c = clients[idx];
                const clientName = c.fullName || c.firstName || 'Client';
                const clientEmail = c.email || '';
                const agr = c.agreement;

                /* Send receipt email via SES */
                if (clientEmail) {
                    const receiptHtml = `
<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">
<tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,'Times New Roman',serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:8px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">Crafting Moments That Last Forever</p>
</td></tr>
<tr><td style="padding:40px 30px">
  <h2 style="margin:0 0 20px;color:#2d3a2d;font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400">Agreement Fully Executed</h2>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">Dear ${clientName.replace(/[<>"]/g, '')},</p>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">Your Events Production &amp; Coordination Agreement has been fully signed by all parties. This email serves as your official receipt and confirmation.</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <p style="margin:0 0 12px;color:#527141;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:600">Agreement Details</p>
      <table width="100%" cellpadding="4" cellspacing="0">
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Event</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(c.eventType || 'Event').replace(/[<>"]/g, '')}${c.eventDate ? ' - ' + c.eventDate.replace(/[<>"]/g, '') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Client Signed</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(agr.coupleSignature || '').replace(/[<>"]/g, '')} on ${agr.coupleSignedAt ? new Date(agr.coupleSignedAt).toLocaleDateString('en-US') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0;border-bottom:1px solid #e0dcd4">Planner Signed</td><td style="color:#2d3a2d;font-size:13px;padding:4px 0;border-bottom:1px solid #e0dcd4;text-align:right">${(agr.plannerSignature || '').replace(/[<>"]/g, '')} on ${agr.plannerSignedAt ? new Date(agr.plannerSignedAt).toLocaleDateString('en-US') : ''}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:4px 0">Status</td><td style="color:#527141;font-size:13px;font-weight:600;padding:4px 0;text-align:right">FULLY EXECUTED</td></tr>
      </table>
    </td></tr>
  </table>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">You can view the full agreement at any time in your <a href="https://rnb716events.com/Client/documents.html" style="color:#527141">Client Portal</a>.</p>
  <p style="color:#888;font-size:12px;line-height:1.6;margin:0">If you have any questions, please reach out to your event planner.</p>
</td></tr>
<tr><td style="background:#2d3a2d;padding:24px 30px;text-align:center">
  <p style="margin:0 0 6px;color:#b89a5e;font-size:12px;letter-spacing:1px">RNB EVENTS</p>
  <p style="margin:0;color:#a3b18a;font-size:11px">www.rnbevents716.com</p>
</td></tr>
</table>
</td></tr></table>
</body></html>`;

                    try {
                        await ses.send(new SendEmailCommand({
                            Source: FROM_EMAIL,
                            Destination: { ToAddresses: [clientEmail.slice(0, 200)] },
                            Message: {
                                Subject: { Data: 'RNB Events - Your Agreement Has Been Fully Executed' },
                                Body: {
                                    Html: { Data: receiptHtml },
                                    Text: { Data: 'Dear ' + clientName + ',\n\nYour Events Production & Coordination Agreement has been fully signed by all parties.\n\nClient Signed: ' + (agr.coupleSignature || '') + ' on ' + (agr.coupleSignedAt || '') + '\nPlanner Signed: ' + (agr.plannerSignature || '') + ' on ' + (agr.plannerSignedAt || '') + '\n\nView your agreement: https://rnb716events.com/Client/documents.html\n\n- RNB Events' }
                                }
                            }
                        }));
                    } catch (emailErr) {
                        console.error('Failed to send agreement receipt:', emailErr);
                    }
                }

                /* Also email planner a copy of the fully-executed agreement */
                const plannerReceiptEmail = (c.plannerEmail || '').trim();
                if (plannerReceiptEmail) {
                    const plannerName = c.planner || 'Vendor';
                    try {
                        await ses.send(new SendEmailCommand({
                            Source: FROM_EMAIL,
                            Destination: { ToAddresses: [plannerReceiptEmail.slice(0, 200)] },
                            Message: {
                                Subject: { Data: `RNB Events \u2014 Agreement Fully Executed: ${(c.fullName || c.firstName || 'Client').replace(/[<>"]/g, '')}` },
                                Body: {
                                    Html: { Data: `<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif"><table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px"><tr><td align="center"><table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden"><tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center"><h1 style="margin:0;color:#b89a5e;font-family:Georgia,serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1></td></tr><tr><td style="padding:40px 30px"><h2 style="margin:0 0 20px;color:#2d3a2d;font-family:Georgia,serif;font-size:22px;font-weight:400">Agreement Fully Executed</h2><p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">Dear ${plannerName.replace(/[<>"]/g, '')},</p><p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">The Event Vendor Agreement for <strong>${(c.fullName || c.firstName || 'Client').replace(/[<>"]/g, '')}</strong> has been fully executed by both parties. This is your copy for your records.</p><table width="100%" cellpadding="4" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px"><tr><td style="padding:16px 20px 4px"><strong style="font-size:11px;color:#527141;letter-spacing:1.5px;text-transform:uppercase">Agreement Details</strong></td></tr><tr><td style="padding:4px 20px;color:#666;font-size:12px">Event</td><td style="padding:4px 20px;color:#2d3a2d;font-size:13px;text-align:right">${(c.eventType || 'Event').replace(/[<>"]/g, '')}${c.eventDate ? ' &mdash; ' + c.eventDate.replace(/[<>"]/g, '') : ''}</td></tr><tr><td style="padding:4px 20px;color:#666;font-size:12px">Client</td><td style="padding:4px 20px;color:#2d3a2d;font-size:13px;text-align:right">${(c.fullName || '').replace(/[<>"]/g, '')}</td></tr><tr><td style="padding:4px 20px;color:#666;font-size:12px">Client Signed</td><td style="padding:4px 20px;color:#2d3a2d;font-size:13px;text-align:right">${(agr.coupleSignature || '').replace(/[<>"]/g, '')} &mdash; ${agr.coupleSignedAt ? new Date(agr.coupleSignedAt).toLocaleDateString('en-US') : ''}</td></tr><tr><td style="padding:4px 20px;color:#666;font-size:12px">Vendor Signed</td><td style="padding:4px 20px;color:#2d3a2d;font-size:13px;text-align:right">${(agr.plannerSignature || '').replace(/[<>"]/g, '')} &mdash; ${agr.plannerSignedAt ? new Date(agr.plannerSignedAt).toLocaleDateString('en-US') : ''}</td></tr><tr><td style="padding:4px 20px 16px;color:#527141;font-size:12px;font-weight:600">Status</td><td style="padding:4px 20px 16px;color:#527141;font-size:13px;font-weight:600;text-align:right">FULLY EXECUTED</td></tr></table><p style="color:#888;font-size:12px;line-height:1.6">View the agreement at any time: <a href="https://rnb716events.com/Client/documents.html" style="color:#527141">Client Portal</a></p></td></tr><tr><td style="background:#2d3a2d;padding:20px 30px;text-align:center"><p style="margin:0;color:#b89a5e;font-size:12px">RNB EVENTS &mdash; www.rnbevents716.com</p></td></tr></table></td></tr></table></body></html>` },
                                    Text: { Data: `Dear ${plannerName},\n\nThe Event Vendor Agreement for ${c.fullName || 'Client'} has been fully executed.\n\nClient Signed: ${agr.coupleSignature || ''} on ${agr.coupleSignedAt || ''}\nVendor Signed: ${agr.plannerSignature || ''} on ${agr.plannerSignedAt || ''}\nEvent: ${c.eventType || ''}${c.eventDate ? ' \u2014 ' + c.eventDate : ''}\n\n- RNB Events` }
                                }
                            }
                        }));
                    } catch (plannerReceiptErr) {
                        console.error('Failed to send planner receipt:', plannerReceiptErr);
                    }
                }

                /* Also create admin task as confirmation */
                createAdminTask({
                    id:         't' + Date.now(),
                    section:    'Client Portal',
                    task:       'Agreement fully executed for ' + clientName + (clientEmail ? ' — receipt sent to ' + clientEmail : ' — no email on file'),
                    priority:   'High',
                    status:     clientEmail ? 'Done' : 'Pending',
                    githubFile: ''
                });
            }

            return respond(200, { ok: true });
        }

        /* ── Branded booking email via SES ──────────── */
        if (path === '/send-booking-email') {
            const { email, fullName, eventType, eventDate, accessCode, plannerCode, teamCode } = body;
            if (!email || typeof email !== 'string') return respond(400, { ok: false, error: 'Missing email' });

            const portalUrl = 'https://rnb716events.com/Client';
            const htmlBody = `
<!DOCTYPE html>
<html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">

<!-- Header -->
<tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,'Times New Roman',serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:8px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">Crafting Moments That Last Forever</p>
</td></tr>

<!-- Body -->
<tr><td style="padding:40px 30px">
  <h2 style="margin:0 0 20px;color:#2d3a2d;font-family:Georgia,'Times New Roman',serif;font-size:22px;font-weight:400">Welcome, ${String(fullName).replace(/[<>"]/g, '')}!</h2>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 20px">We are thrilled to officially welcome you to the RNB Events family. Your${eventType ? ' <strong>' + String(eventType).replace(/[<>"]/g, '') + '</strong>' : ' event'}${eventDate ? ' on <strong>' + String(eventDate).replace(/[<>"]/g, '') + '</strong>' : ''} is going to be unforgettable.</p>
  <p style="color:#3d3d3d;font-size:14px;line-height:1.7;margin:0 0 24px">Your personalized client portal is ready. Use the access codes below to log in and start planning with your team.</p>

  <!-- Access Codes -->
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <p style="margin:0 0 12px;color:#527141;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:600">Your Access Codes</p>
      <table width="100%" cellpadding="6" cellspacing="0">
        <tr>
          <td style="color:#666;font-size:12px;letter-spacing:0.5px;padding:6px 0;border-bottom:1px solid #e0dcd4">COUPLE (Your Code)</td>
          <td style="color:#2d3a2d;font-size:16px;font-weight:600;font-family:monospace;padding:6px 0;border-bottom:1px solid #e0dcd4;text-align:right">${String(accessCode).replace(/[<>"]/g, '')}</td>
        </tr>
        ${plannerCode ? `<tr>
          <td style="color:#666;font-size:12px;letter-spacing:0.5px;padding:6px 0;border-bottom:1px solid #e0dcd4">PLANNER</td>
          <td style="color:#527141;font-size:16px;font-weight:600;font-family:monospace;padding:6px 0;border-bottom:1px solid #e0dcd4;text-align:right">${String(plannerCode).replace(/[<>"]/g, '')}</td>
        </tr>` : ''}
        ${teamCode ? `<tr>
          <td style="color:#666;font-size:12px;letter-spacing:0.5px;padding:6px 0">RNB TEAM</td>
          <td style="color:#2d3a2d;font-size:16px;font-weight:600;font-family:monospace;padding:6px 0;text-align:right">${String(teamCode).replace(/[<>"]/g, '')}</td>
        </tr>` : ''}
      </table>
    </td></tr>
  </table>

  <!-- CTA Button -->
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr><td align="center" style="padding:10px 0 20px">
      <a href="${portalUrl}" style="display:inline-block;background:#527141;color:#fff;text-decoration:none;padding:14px 36px;border-radius:3px;font-size:12px;letter-spacing:2px;text-transform:uppercase;font-weight:500">ACCESS YOUR PORTAL</a>
    </td></tr>
  </table>

  <p style="color:#888;font-size:12px;line-height:1.6;margin:0">Keep these codes safe. Each code grants different access levels to your planning portal. Share the Planner code with your event coordinator only.</p>
</td></tr>

<!-- Footer -->
<tr><td style="background:#2d3a2d;padding:24px 30px;text-align:center">
  <p style="margin:0 0 6px;color:#b89a5e;font-size:12px;letter-spacing:1px">RNB EVENTS</p>
  <p style="margin:0;color:#a3b18a;font-size:11px">www.rnbevents716.com</p>
</td></tr>

</table>
</td></tr></table>
</body></html>`;

            const textBody = `Welcome, ${String(fullName)}!\n\nYour client portal is ready at ${portalUrl}\n\nAccess Codes:\n- Couple: ${accessCode}\n${plannerCode ? '- Planner: ' + plannerCode + '\n' : ''}${teamCode ? '- RNB Team: ' + teamCode + '\n' : ''}\nKeep these codes safe.\n\n- RNB Events\nwww.rnbevents716.com`;

            await ses.send(new SendEmailCommand({
                Source: FROM_EMAIL,
                Destination: { ToAddresses: [String(email).slice(0, 200)] },
                Message: {
                    Subject: { Data: 'Welcome to RNB Events - Your Client Portal Access' },
                    Body: {
                        Html: { Data: htmlBody },
                        Text: { Data: textBody }
                    }
                }
            }));

            return respond(200, { ok: true });
        }

        /* ── Client: upload image file ───────────────── */
        if (path === '/upload-file') {
            const { codeHash, fileName, contentType, data } = body;
            if (!codeHash || typeof codeHash !== 'string') return respond(400, { ok: false, error: 'Missing codeHash' });
            if (!data || typeof data !== 'string') return respond(400, { ok: false, error: 'Missing file data' });

            const ALLOWED_TYPES = {
                'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif',
                'application/pdf': 'pdf',
                'application/msword': 'doc',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx'
            };
            const ext = ALLOWED_TYPES[(contentType || '').toLowerCase()];
            if (!ext) return respond(400, { ok: false, error: 'Only images (JPEG/PNG/WebP/GIF) or documents (PDF/DOC/DOCX) are allowed.' });

            const buf = Buffer.from(data, 'base64');
            if (buf.length > 15 * 1024 * 1024) return respond(400, { ok: false, error: 'File exceeds 15 MB limit.' });

            const clients = await readClients();
            const idx = findClientByAnyHash(clients, codeHash);
            if (idx === -1) return respond(404, { ok: false, error: 'Client not found' });

            const safeName = String(fileName || 'file').replace(/[^a-zA-Z0-9._-]/g, '_').replace(/\.[^.]+$/, '').slice(0, 80);
            const key = `client-uploads/${clients[idx].codeHash}/${Date.now()}-${safeName}.${ext}`;
            const mimeType = contentType.startsWith('image/') ? contentType : (ext === 'pdf' ? 'application/pdf' : ext === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : 'application/msword');

            await s3.send(new PutObjectCommand({
                Bucket: BUCKET,
                Key: key,
                Body: buf,
                ContentType: mimeType
            }));

            const fileUrl = `https://${BUCKET}.s3.us-east-2.amazonaws.com/${key}`;
            return respond(200, { ok: true, url: fileUrl });
        }

        /* ── Public quote request ─────────────────── */
        if (path === '/send-quote-request') {
            const { name, email, phone, location, eventType, eventDate, guestCount, budget, serviceScale, message } = body;
            if (!name  || typeof name  !== 'string') return respond(400, { ok: false, error: 'Name is required' });
            if (!email || typeof email !== 'string' || !/^[^@]+@[^@]+\.[^@]+$/.test(email))
                return respond(400, { ok: false, error: 'A valid email address is required' });

            const safe = s => String(s || '').replace(/[<>"]/g, '').slice(0, 500);

            const htmlBody = `
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">
<tr><td style="background:#2d3a2d;padding:36px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,serif;font-size:26px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:6px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">New Quote Request</p>
</td></tr>
<tr><td style="padding:36px 30px">
  <h2 style="margin:0 0 6px;color:#2d3a2d;font-family:Georgia,serif;font-size:20px;font-weight:400">Quote Request from ${safe(name)}</h2>
  <p style="margin:0 0 24px;color:#888;font-size:12px">${safe(email)}</p>
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-radius:4px;margin:0 0 24px">
    <tr><td style="padding:24px">
      <table width="100%" cellpadding="5" cellspacing="0">
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Name</td><td style="color:#2d3a2d;font-size:13px;font-weight:600;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(name)}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Email</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(email)}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Phone</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(phone) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Location / City</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(location) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Event Type</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(eventType) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Event Date</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(eventDate) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Guest Count</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(guestCount) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;border-bottom:1px solid #e0dcd4;padding:8px 0">Budget Range</td><td style="color:#2d3a2d;font-size:13px;border-bottom:1px solid #e0dcd4;padding:8px 0;text-align:right">${safe(budget) || '—'}</td></tr>
        <tr><td style="color:#666;font-size:12px;padding:8px 0">Service Level</td><td style="color:#2d3a2d;font-size:13px;font-weight:600;padding:8px 0;text-align:right">${safe(serviceScale) || '—'}/10</td></tr>
      </table>
    </td></tr>
  </table>
  ${message ? `<p style="color:#666;font-size:11px;letter-spacing:1px;text-transform:uppercase;margin:0 0 8px">Message</p><p style="color:#3d3d3d;font-size:14px;line-height:1.7;background:#f9f7f4;padding:16px;border-radius:4px;margin:0 0 20px">${safe(message)}</p>` : ''}
  <p style="color:#888;font-size:12px">Received ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York', dateStyle: 'full', timeStyle: 'short' })} ET</p>
</td></tr>
<tr><td style="background:#2d3a2d;padding:20px 30px;text-align:center">
  <p style="margin:0 0 4px;color:#a3b18a;font-size:11px">RNB Events Production &amp; Coordination LLC</p>
  <p style="margin:0;color:#527141;font-size:10px">info@rnbevents716.com &nbsp;&middot;&nbsp; rnbevents716.com</p>
</td></tr>
</table></td></tr></table>
</body></html>`;

            /* Save lead first — this must never be lost even if email fails */
            await createAdminProspect({
                id:        'lead_' + Date.now(),
                name:      safe(name),
                email:     safe(email),
                phone:     safe(phone) || '',
                eventType: safe(eventType) || '',
                eventDate: safe(eventDate) || '',
                status:    'New Lead',
                notes:     'Website quote request.' +
                           (budget      ? ' Budget: '        + safe(budget)       : '') +
                           (location    ? ' Location: '      + safe(location)     : '') +
                           (guestCount  ? ' Guests: '        + safe(guestCount)   : '') +
                           (serviceScale? ' Service Level: ' + safe(serviceScale) + '/10' : '') +
                           (message     ? ' Message: '       + safe(message)      : ''),
                added:     new Date().toISOString().slice(0, 10)
            }).catch(e => console.error('Prospect registration failed:', e));

            /* Send notification email — best effort; failure still returns 200 since lead is saved */
            try {
                await ses.send(new SendEmailCommand({
                    Source: FROM_EMAIL,
                    Destination: { ToAddresses: [RECOVERY_EMAIL], BccAddresses: [INFO_EMAIL] },
                    ReplyToAddresses: [String(email).slice(0, 200)],
                    Message: {
                        Subject: { Data: `Quote Request: ${safe(name)} — ${safe(eventType) || 'Event'}` },
                        Body: {
                            Html: { Data: htmlBody },
                            Text: { Data: `New Quote Request\n\nName: ${safe(name)}\nEmail: ${safe(email)}\nPhone: ${safe(phone)}\nLocation: ${safe(location)}\nEvent: ${safe(eventType)}\nDate: ${safe(eventDate)}\nGuests: ${safe(guestCount)}\nBudget: ${safe(budget)}\nService Level: ${safe(serviceScale)}/10\n\nMessage:\n${safe(message)}` }
                        }
                    }
                }));
            } catch (sesErr) {
                console.error('Quote notification email failed (lead was still saved):', sesErr);
            }

            return respond(200, { ok: true });
        }

        /* ── Admin password reset via email ─────────── */
        if (path === '/send-reset-code') {
            const { action, code } = body;

            if (action === 'send') {
                const pin = String(Math.floor(100000 + Math.random() * 900000));
                const expiry = Date.now() + 10 * 60 * 1000; /* 10 min */
                await s3.send(new PutObjectCommand({
                    Bucket: BUCKET,
                    Key: RESET_CODE_KEY,
                    Body: JSON.stringify({ code: pin, expiry }),
                    ContentType: 'application/json'
                }));

                await ses.send(new SendEmailCommand({
                    Source: FROM_EMAIL,
                    Destination: { ToAddresses: [RECOVERY_EMAIL] },
                    Message: {
                        Subject: { Data: 'RNB Events Admin - Password Reset Code' },
                        Body: {
                            Text: { Data: 'Your admin password reset code is: ' + pin + '\n\nThis code expires in 10 minutes.\n\nIf you did not request this, ignore this email.' }
                        }
                    }
                }));

                return respond(200, { ok: true });
            }

            if (action === 'verify') {
                if (!code || typeof code !== 'string') return respond(400, { ok: false, error: 'Missing code' });

                let stored;
                try {
                    const res = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: RESET_CODE_KEY }));
                    stored = JSON.parse(await res.Body.transformToString());
                } catch (e) {
                    return respond(400, { ok: false, error: 'No reset code pending.' });
                }

                if (!stored || Date.now() > stored.expiry) {
                    return respond(400, { ok: false, error: 'Code expired. Request a new one.' });
                }
                if (code !== stored.code) {
                    return respond(400, { ok: false, error: 'Invalid code.' });
                }

                /* Clean up used code */
                try {
                    await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: RESET_CODE_KEY }));
                } catch (e) {}

                return respond(200, { ok: true });
            }

            return respond(400, { ok: false, error: 'Invalid action' });
        }

        /* ── Analytics: log a page view to S3 ─────── */
        if (path === '/track-visit') {
            const VALID_SECTIONS = ['public', 'admin', 'client', 'prospect'];
            const VALID_TYPES    = ['page_view', 'click'];
            const section  = VALID_SECTIONS.includes(body.section) ? body.section : 'public';
            const entryType = VALID_TYPES.includes(body.type) ? body.type : 'page_view';

            const sourceIp = (event.requestContext && event.requestContext.http)
                ? (event.requestContext.http.sourceIp || '')
                : '';

            const dateKey = new Date().toISOString().slice(0, 10);
            const s3Key   = `logs/visits-${dateKey}.ndjson`;

            /* Run geo lookup and S3 read in parallel */
            const [geo, existingContent] = await Promise.all([
                geoLookup(sourceIp),
                s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: s3Key }))
                    .then(r => r.Body.transformToString())
                    .catch(() => '')
            ]);

            const entry = {
                ts:          new Date().toISOString(),
                section,
                type:        entryType,
                action:      entryType === 'click' ? String(body.action || '').slice(0, 100) : '',
                page:        String(body.page        || '').slice(0, 500),
                title:       String(body.title       || '').slice(0, 500),
                referrer:    String(body.referrer    || '').slice(0, 2000),
                utmSource:   String(body.utmSource   || '').slice(0, 200),
                utmMedium:   String(body.utmMedium   || '').slice(0, 200),
                utmCampaign: String(body.utmCampaign || '').slice(0, 200),
                utmTerm:     String(body.utmTerm     || '').slice(0, 500),
                sessionId:   String(body.sessionId   || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64),
                codeHash:    section === 'public' ? '' : String(body.codeHash || '').slice(0, 100),
                loadMs:      entryType === 'page_view' && Number.isFinite(body.loadMs) ? Math.round(body.loadMs) : null,
                city:        geo.city,
                country:     geo.country
            };

            await s3.send(new PutObjectCommand({
                Bucket: BUCKET, Key: s3Key,
                Body: existingContent + JSON.stringify(entry) + '\n',
                ContentType: 'application/x-ndjson',
                CacheControl: 'no-cache, no-store, must-revalidate'
            }));

            return respond(200, { ok: true });
        }

        /* ── Admin: send package quote to prospect ────── */
        if (path === '/send-quote-email') {
            const { name, email, eventType, eventDate, package: pkg, lineItems, estimatedAmount, customNote, customFeatures,
                    discountPct, discountAmt, laborProduction, taxAmt, deposit, grandTotal: clientGrandTotal } = body;
            if (!name  || typeof name  !== 'string') return respond(400, { ok: false, error: 'Name is required' });
            if (!email || typeof email !== 'string' || !/^[^@]+@[^@]+\.[^@]+$/.test(email))
                return respond(400, { ok: false, error: 'A valid email address is required' });

            const VALID_PACKAGES = ['Silver', 'Gold', 'Platinum', 'Presidential'];
            const safePkg = VALID_PACKAGES.includes(pkg) ? pkg : 'Silver';
            const safe    = s => String(s || '').replace(/[<>"']/g, '').slice(0, 500);
            const safeAmt = v => { const n = parseFloat(v); return (!isNaN(n) && n > 0) ? n : null; };

            const PACKAGES = {
                Silver:      { tagline: 'Essentials Package',    color: '#7a8fa6', desc: 'Perfect for intimate gatherings and smaller celebrations. Covers the core elements of event coordination so your day runs smoothly.' },
                Gold:        { tagline: 'Full-Service Package',  color: '#b89a5e', desc: 'Our most popular package — comprehensive planning and coordination from first meeting to final farewell, with hands-on support every step of the way.' },
                Platinum:    { tagline: 'Premium Experience',    color: '#557a55', desc: 'An elevated, white-glove planning experience for clients who want every detail curated to perfection. We handle everything — you simply celebrate.' },
                Presidential:{ tagline: 'Ultra-Luxury Package',  color: '#2d3a2d', desc: 'The pinnacle of the RNB Events experience. Reserved for the most discerning clients — a fully bespoke, end-to-end luxury event production with no detail overlooked.' }
            };

            const p = PACKAGES[safePkg];

            /* ── Build line items ─────────────────────────── */
            /* Accept new lineItems array; fall back to legacy customFeatures list */
            let items = [];
            let grandTotal = 0;

            if (Array.isArray(lineItems) && lineItems.length > 0) {
                items = lineItems.slice(0, 50).map(item => ({
                    description: String(item.description || '').replace(/[<>"]/g, '').slice(0, 300),
                    qty:   Math.max(0, parseFloat(item.qty)   || 1),
                    price: parseFloat(item.price) || 0
                })).filter(item => item.description.trim());
                grandTotal = items.reduce((sum, item) => sum + (item.qty * item.price), 0);
            } else if (Array.isArray(customFeatures) && customFeatures.length > 0) {
                /* Legacy: plain text feature list (no pricing) */
                items = customFeatures.slice(0, 50).map(f => ({
                    description: String(f).replace(/[<>"]/g, '').slice(0, 300),
                    qty: null, price: null
                })).filter(item => item.description.trim());
                /* Legacy estimatedAmount */
                grandTotal = safeAmt(estimatedAmount) || 0;
            }

            /* New breakdown fields (sent from admin quote builder) */
            const hasBreakdown = clientGrandTotal != null && (discountPct != null || laborProduction != null || taxAmt != null);
            const safeNum = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };
            const bDiscountPct     = safeNum(discountPct);
            const bDiscountAmt     = safeNum(discountAmt);
            const bLaborProduction = safeNum(laborProduction);
            const bTaxAmt          = safeNum(taxAmt);
            const bDeposit         = safeNum(deposit);
            const bGrandTotal      = hasBreakdown ? safeNum(clientGrandTotal) : grandTotal;
            const fmtUSD = n => '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

            /* Recompute items-only subtotal for breakdown display */
            const bItemsSubtotal = items.reduce((sum, item) => sum + (item.qty || 1) * (item.price || 0), 0);

            /* ── Invoice line items HTML ─────────────────── */
            const hasLinePrices = items.some(item => item.price !== null && item.price > 0);

            const lineItemsHtml = items.map(item => {
                if (item.qty === null) {
                    /* Legacy text-only row */
                    return `<tr>
                      <td colspan="4" style="padding:8px 0;font-size:13px;color:#3d3d3d;border-bottom:1px solid #f0ece6">&#10003;&nbsp; ${item.description}</td>
                    </tr>`;
                }
                const sub = item.qty * item.price;
                return `<tr>
                  <td style="padding:9px 0;font-size:13px;color:#3d3d3d;border-bottom:1px solid #f0ece6">${item.description}</td>
                  <td style="padding:9px 8px;font-size:13px;color:#555;text-align:center;border-bottom:1px solid #f0ece6">${item.qty}</td>
                  <td style="padding:9px 0;font-size:13px;color:#555;text-align:right;border-bottom:1px solid #f0ece6">${item.price > 0 ? fmtUSD(item.price) : '—'}</td>
                  <td style="padding:9px 0;font-size:13px;color:#2d3a2d;font-weight:600;text-align:right;border-bottom:1px solid #f0ece6">${sub > 0 ? fmtUSD(sub) : '—'}</td>
                </tr>`;
            }).join('');

            const lineItemsHeaderHtml = hasLinePrices ? `
              <tr style="background:#f5f2ec">
                <th style="padding:8px 0;font-size:10px;letter-spacing:1.5px;color:#527141;text-transform:uppercase;font-weight:600;text-align:left;border-bottom:2px solid #2d3a2d">Description</th>
                <th style="padding:8px 8px;font-size:10px;letter-spacing:1.5px;color:#527141;text-transform:uppercase;font-weight:600;text-align:center;border-bottom:2px solid #2d3a2d">Qty</th>
                <th style="padding:8px 0;font-size:10px;letter-spacing:1.5px;color:#527141;text-transform:uppercase;font-weight:600;text-align:right;border-bottom:2px solid #2d3a2d">Unit Price</th>
                <th style="padding:8px 0;font-size:10px;letter-spacing:1.5px;color:#527141;text-transform:uppercase;font-weight:600;text-align:right;border-bottom:2px solid #2d3a2d">Amount</th>
              </tr>` : '';

            /* Breakdown rows (new format) or simple total row (legacy) */
            const totalRowHtml = hasBreakdown ? `
              <tr><td colspan="4" style="padding:0"><table width="100%" cellpadding="0" cellspacing="0">
                <tr><td colspan="2" style="border-top:1px solid #e0dcd4;padding-top:8px"></td></tr>
                ${bItemsSubtotal > 0 ? `<tr>
                  <td style="padding:5px 0;font-size:11px;color:#888;letter-spacing:1px;text-transform:uppercase">Items Subtotal</td>
                  <td style="padding:5px 0;font-size:12px;color:#555;text-align:right">${fmtUSD(bItemsSubtotal)}</td>
                </tr>` : ''}
                ${bDiscountPct > 0 ? `<tr>
                  <td style="padding:5px 0;font-size:11px;color:#c0392b;letter-spacing:1px">Family &amp; Friends Discount (${bDiscountPct}%)</td>
                  <td style="padding:5px 0;font-size:12px;color:#c0392b;text-align:right">-${fmtUSD(bDiscountAmt)}</td>
                </tr>` : ''}
                ${bLaborProduction > 0 ? `<tr>
                  <td style="padding:5px 0;font-size:11px;color:#3d3d3d;letter-spacing:0.5px">Labor Production <span style="font-size:9px;color:#888">(labor, setup &amp; teardown)</span></td>
                  <td style="padding:5px 0;font-size:12px;color:#3d3d3d;text-align:right">${fmtUSD(bLaborProduction)}</td>
                </tr>` : ''}
                ${bTaxAmt > 0 ? `<tr>
                  <td style="padding:5px 0;font-size:11px;color:#888;letter-spacing:0.5px">Texas Sales Tax (8.25%) — non-modifiable</td>
                  <td style="padding:5px 0;font-size:12px;color:#888;text-align:right">${fmtUSD(bTaxAmt)}</td>
                </tr>` : ''}
                ${bDeposit > 0 ? `<tr>
                  <td style="padding:5px 0;font-size:11px;color:#527141;letter-spacing:1px">Required Deposit</td>
                  <td style="padding:5px 0;font-size:12px;color:#527141;text-align:right">${fmtUSD(bDeposit)}</td>
                </tr>` : ''}
                <tr><td colspan="2" style="border-top:2px solid #2d3a2d;padding-top:10px"></td></tr>
                <tr>
                  <td style="padding:4px 0;font-size:11px;letter-spacing:1.5px;color:#2d3a2d;text-transform:uppercase;font-weight:600">Grand Total</td>
                  <td style="padding:4px 0;text-align:right">
                    <span style="font-family:Georgia,serif;font-size:24px;color:#b89a5e;font-weight:400">${fmtUSD(bGrandTotal)}</span>
                  </td>
                </tr>
              </table></td></tr>` :
              (grandTotal > 0 ? `<tr>
                <td colspan="${hasLinePrices ? '3' : '4'}" style="padding:14px 0 6px;text-align:right;font-size:11px;letter-spacing:1.5px;color:#888;text-transform:uppercase">Estimated Total</td>
                ${hasLinePrices ? `<td style="padding:14px 0 6px;text-align:right">
                  <span style="font-family:Georgia,serif;font-size:22px;color:#b89a5e;font-weight:400">${fmtUSD(grandTotal)}</span>
                </td>` : ''}
              </tr>` : '');

            /* Use breakdown grand total if present */
            if (hasBreakdown) grandTotal = bGrandTotal;

            /* Personal note block */
            const safeNote = customNote ? String(customNote).replace(/[<>"]/g, '').slice(0, 800) : '';
            const noteHtml = safeNote ? `
  <!-- Personal Note -->
  <tr><td style="padding:0 36px 28px">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;border-left:3px solid #b89a5e;border-radius:0 4px 4px 0">
      <tr><td style="padding:16px 20px">
        <p style="margin:0 0 6px;color:#888;font-size:10px;letter-spacing:2px;text-transform:uppercase">A Note From Our Team</p>
        <p style="margin:0;color:#3d3d3d;font-size:13px;line-height:1.8">${safeNote}</p>
      </td></tr>
    </table>
  </td></tr>` : '';

            const quoteHtml = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.07)">

  <!-- Header with logo -->
  <tr><td style="background:#2d3a2d;padding:32px 36px;text-align:center">
    <img src="https://rnbevents716.com/RNB%20Logo%20Olive.png" alt="RNB Events" width="120" style="display:block;margin:0 auto 12px;max-width:120px">
    <h1 style="margin:0 0 4px;color:#b89a5e;font-family:Georgia,serif;font-size:26px;font-weight:300;letter-spacing:4px">RNB EVENTS</h1>
    <p style="margin:0;color:#a3b18a;font-size:11px;letter-spacing:3px;text-transform:uppercase">Events Production &amp; Coordination LLC</p>
  </td></tr>

  <!-- Quote label + ref -->
  <tr><td style="padding:28px 36px 0">
    <table width="100%" cellpadding="0" cellspacing="0">
      <tr>
        <td>
          <p style="margin:0 0 2px;color:#527141;font-size:10px;letter-spacing:2px;text-transform:uppercase">Personalized Quote</p>
          <h2 style="margin:0;color:#2d3a2d;font-family:Georgia,serif;font-size:22px;font-weight:400">Hello, ${safe(name)}</h2>
        </td>
        <td style="text-align:right;vertical-align:top">
          <p style="margin:0 0 2px;color:#888;font-size:10px;letter-spacing:1px;text-transform:uppercase">Date</p>
          <p style="margin:0;color:#2d3a2d;font-size:12px">${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</p>
        </td>
      </tr>
    </table>
    <p style="margin:14px 0 0;color:#555;font-size:13px;line-height:1.8">Thank you for your interest in RNB Events. Based on your ${safe(eventType) || 'event'}${safe(eventDate) ? ' on <strong>' + safe(eventDate) + '</strong>' : ''}, we&rsquo;re excited to present the following package proposal.</p>
  </td></tr>

  <!-- Divider -->
  <tr><td style="padding:20px 36px 0"><hr style="border:none;border-top:1px solid #e8e2d9;margin:0"></td></tr>

  <!-- Package badge -->
  <tr><td style="padding:20px 36px 0">
    <table cellpadding="0" cellspacing="0">
      <tr>
        <td style="background:${p.color};padding:6px 16px;border-radius:20px">
          <span style="color:#fff;font-size:11px;letter-spacing:2px;text-transform:uppercase;font-family:'Helvetica Neue',Arial,sans-serif">${safePkg} — ${p.tagline}</span>
        </td>
      </tr>
    </table>
    <p style="margin:10px 0 0;color:#3d3d3d;font-size:13px;line-height:1.8">${p.desc}</p>
  </td></tr>

  <!-- Line Items -->
  <tr><td style="padding:20px 36px 0">
    <table width="100%" cellpadding="0" cellspacing="0">
      ${lineItemsHeaderHtml}
      ${lineItemsHtml}
      ${totalRowHtml}
    </table>
  </td></tr>

  <tr><td style="padding:6px 36px 0"><hr style="border:none;border-top:1px solid #e8e2d9;margin:0"></td></tr>

  ${noteHtml}

  <!-- Disclaimer -->
  <tr><td style="padding:20px 36px">
    <p style="margin:0;color:#aaa;font-size:11px;line-height:1.7;font-style:italic">* All estimates are based on preliminary planning details and are subject to review during your consultation. Final pricing will be confirmed in your event agreement.</p>
  </td></tr>

  <!-- CTA -->
  <tr><td style="padding:0 36px 32px;text-align:center">
    <p style="margin:0 0 20px;color:#555;font-size:13px;line-height:1.8">Ready to move forward or have questions? We&rsquo;d love to connect. Reply to this email or reach us directly:</p>
    <a href="mailto:info@rnbevents716.com" style="display:inline-block;background:#2d3a2d;color:#b89a5e;font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;letter-spacing:2px;text-transform:uppercase;padding:14px 32px;border-radius:3px;text-decoration:none">REPLY TO THIS QUOTE</a>
    <p style="margin:20px 0 0;color:#888;font-size:11px">Or visit us at <a href="https://rnbevents716.com" style="color:#527141">rnbevents716.com</a></p>
  </td></tr>

  <!-- Footer -->
  <tr><td style="background:#2d3a2d;padding:24px 36px;text-align:center">
    <p style="margin:0 0 4px;color:#a3b18a;font-size:11px;letter-spacing:1px">RNB Events Production &amp; Coordination LLC</p>
    <p style="margin:0 0 6px;color:#527141;font-size:10px">info@rnbevents716.com &nbsp;&middot;&nbsp; rnbevents716.com</p>
    <p style="margin:0;color:#527141;font-size:9px">A product of RNB Events &nbsp;&middot;&nbsp; Powered by <a href="https://ynk-techusa.com" style="color:#a3b18a;text-decoration:none">ynk-techusa.com</a></p>
  </td></tr>

</table>
</td></tr></table>
</body></html>`;

            const plainLines = items.map(item =>
                item.qty !== null
                    ? `  ${item.description}${item.qty !== 1 ? ' (x'+item.qty+')' : ''}${item.price > 0 ? ' — $'+(item.qty*item.price).toFixed(2) : ''}`
                    : `  • ${item.description}`
            ).join('\n');
            const plainTotal = grandTotal > 0 ? `\nEstimated Total: $${grandTotal.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}\n` : '';
            const plainNote  = safeNote ? `\nNote from our team:\n${safeNote}\n` : '';

            const plainText = `Hello ${safe(name)},\n\nThank you for your interest in RNB Events!\n\n${safePkg} — ${p.tagline}\n${p.desc}\n\n${plainLines}${plainTotal}${plainNote}\nReady to move forward? Reply to this email or visit rnbevents716.com.\n\n— RNB Events Team\nrnbevents716@gmail.com`;

            /* ── Generate PDF ─────────────────────────────── */
            const pdfBuf = await generateQuotePDF({
                name: safe(name),
                pkg:  safePkg,
                pkgData: p,
                items,
                grandTotal:      bGrandTotal,
                itemsSubtotal:   bItemsSubtotal,
                discountPct:     hasBreakdown ? bDiscountPct      : 0,
                discountAmt:     hasBreakdown ? bDiscountAmt      : 0,
                laborProduction: hasBreakdown ? bLaborProduction  : 0,
                taxAmt:          hasBreakdown ? bTaxAmt           : 0,
                deposit:         hasBreakdown ? bDeposit          : 0,
                customNote: safeNote,
                eventType:  safe(eventType),
                eventDate:  safe(eventDate)
            });

            /* ── Save PDF to S3 (backup + admin download) ──── */
            const quoteKey = `quotes/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.pdf`;
            try {
                await s3.send(new PutObjectCommand({
                    Bucket: BUCKET,
                    Key: quoteKey,
                    Body: pdfBuf,
                    ContentType: 'application/pdf'
                }));
            } catch (s3Err) {
                console.error('S3 quote save failed:', s3Err.message);
            }

            /* ── Try sending PDF email to client ──────────── */
            const pdfFilename = `RNB-Events-${safePkg}-Quote.pdf`;
            const clientSubject = `Your RNB Events ${safePkg} Package Quote`;
            let clientEmailSent = false;
            try {
                const rawMsg = buildRawEmail(
                    String(email).slice(0, 200),
                    clientSubject,
                    quoteHtml,
                    plainText,
                    pdfBuf,
                    pdfFilename,
                    INFO_EMAIL
                );
                await ses.send(new SendRawEmailCommand({ RawMessage: { Data: rawMsg } }));
                clientEmailSent = true;
            } catch (sesErr) {
                console.error('SES client send failed (likely sandbox):', sesErr.message);
            }

            /* ── Fallback: notify admin with PDF attached ──── */
            if (!clientEmailSent) {
                try {
                    const adminSubject = `[QUOTE READY] ${safePkg} package for ${safe(name)} <${String(email).slice(0, 200)}>`;
                    const adminHtml = `<div style="font-family:Arial,sans-serif;padding:20px;max-width:600px">
<h2 style="color:#2d3a2d">Quote Ready to Forward</h2>
<p>A <strong>${safePkg}</strong> package quote for <strong>${safe(name)}</strong> has been generated.</p>
<table style="border-collapse:collapse;margin:12px 0">
  <tr><td style="padding:4px 12px 4px 0;color:#888;font-size:13px">Client email:</td><td style="font-size:13px"><strong>${String(email).slice(0,200)}</strong></td></tr>
  <tr><td style="padding:4px 12px 4px 0;color:#888;font-size:13px">Package:</td><td style="font-size:13px">${safePkg}</td></tr>
  ${grandTotal !== 0 ? `<tr><td style="padding:4px 12px 4px 0;color:#888;font-size:13px">Total:</td><td style="font-size:13px;color:#b89a5e;font-weight:bold">$${grandTotal.toLocaleString('en-US',{minimumFractionDigits:2})}</td></tr>` : ''}
</table>
<p style="color:#c0392b;font-weight:bold">&#9888; SES is in sandbox mode &mdash; the client did not receive this automatically.<br>Please open the attached PDF and forward it to <strong>${String(email).slice(0,200)}</strong>.</p>
<p style="color:#555;font-size:12px">Once you request SES production access, quotes will be delivered to clients directly.</p>
</div>`;
                    const adminPlain = `Quote ready for ${safe(name)} (${String(email).slice(0,200)})\nPackage: ${safePkg}${grandTotal !== 0 ? '\nTotal: $' + grandTotal.toLocaleString('en-US',{minimumFractionDigits:2}) : ''}\n\nSES sandbox mode is active. Please forward the attached PDF to the client.`;
                    const adminRaw = buildRawEmail(
                        RECOVERY_EMAIL,
                        adminSubject,
                        adminHtml,
                        adminPlain,
                        pdfBuf,
                        pdfFilename,
                        INFO_EMAIL
                    );
                    await ses.send(new SendRawEmailCommand({ RawMessage: { Data: adminRaw } }));
                } catch (adminErr) {
                    console.error('Admin fallback email failed:', adminErr.message);
                }
            }

            return respond(200, { ok: true });
        }

        /* ── Post-event task runner ────────────────────── */
        if (path === '/run-post-event-tasks') {
            const clients      = await readClients();
            const now          = new Date();
            const TWO_DAYS_MS  = 2 * 24 * 60 * 60 * 1000;
            const processed    = [];

            function parseDDMMYYYY(str) {
                const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(String(str || ''));
                if (!m) return null;
                return new Date(parseInt(m[3], 10), parseInt(m[2], 10) - 1, parseInt(m[1], 10));
            }

            const thankYouHtml = (clientName, eventType, eventDate, recipientType) => `
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#faf8f5;font-family:'Helvetica Neue',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f5;padding:40px 20px">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:4px;overflow:hidden">
<tr><td style="background:#2d3a2d;padding:40px 30px;text-align:center">
  <h1 style="margin:0;color:#b89a5e;font-family:Georgia,serif;font-size:28px;font-weight:300;letter-spacing:3px">RNB EVENTS</h1>
  <p style="margin:8px 0 0;color:#a3b18a;font-size:11px;letter-spacing:2px;text-transform:uppercase">Crafting Moments That Last Forever</p>
</td></tr>
<tr><td style="padding:40px 30px;text-align:center">
  <h2 style="margin:0 0 14px;color:#2d3a2d;font-family:Georgia,serif;font-size:26px;font-weight:400">Thank You!</h2>
  <p style="color:#3d3d3d;font-size:15px;line-height:1.8;margin:0 0 20px">Dear ${clientName.replace(/[<>"]/g, '')},</p>
  ${recipientType === 'client'
    ? `<p style="color:#3d3d3d;font-size:14px;line-height:1.8;margin:0 0 24px">We are so honored to have been a part of your <strong>${(eventType || 'event').replace(/[<>"]/g, '')}</strong>${eventDate ? ' on <strong>' + eventDate.replace(/[<>"]/g, '') + '</strong>' : ''}. It was a privilege to help bring your vision to life, and we hope every detail exceeded your expectations.</p><p style="color:#3d3d3d;font-size:14px;line-height:1.8;margin:0 0 24px">We would love to hear about your experience. If you have a moment, please consider leaving us a review &mdash; it means the world to us and helps us continue crafting unforgettable moments for others.</p>` 
    : `<p style="color:#3d3d3d;font-size:14px;line-height:1.8;margin:0 0 24px">Thank you for your partnership on the <strong>${(eventType || 'event').replace(/[<>"]/g, '')}</strong>${eventDate ? ' on <strong>' + eventDate.replace(/[<>"]/g, '') + '</strong>' : ''}. Your professionalism and collaboration made this event a success, and we deeply appreciate working alongside you.</p>` }
  <div style="margin:28px auto;width:60px;height:2px;background:#b89a5e"></div>
  <p style="color:#527141;font-size:13px;line-height:1.7;margin:0 0 8px">From all of us at RNB Events,</p>
  <p style="color:#2d3a2d;font-size:15px;font-family:Georgia,serif;font-weight:400;margin:0">Thank you for choosing RNB Events.</p>
</td></tr>
<tr><td style="background:#2d3a2d;padding:24px 30px;text-align:center">
  <p style="margin:0 0 6px;color:#b89a5e;font-size:12px;letter-spacing:1px">RNB EVENTS</p>
  <p style="margin:0;color:#a3b18a;font-size:11px">www.rnbevents716.com</p>
</td></tr>
</table>
</td></tr></table>
</body></html>`;

            for (const c of clients) {
                if (c.archived) continue;
                if (!c.eventDate) continue;
                const ed = parseDDMMYYYY(c.eventDate);
                if (!ed) continue;
                const msSinceEvent = now - ed;
                if (msSinceEvent < TWO_DAYS_MS) continue;

                const clientName = c.fullName || c.firstName || 'Valued Client';

                /* Send thank-you to client */
                if (c.email) {
                    try {
                        await ses.send(new SendEmailCommand({
                            Source: FROM_EMAIL,
                            Destination: { ToAddresses: [c.email.slice(0, 200)] },
                            Message: {
                                Subject: { Data: 'Thank You for Choosing RNB Events!' },
                                Body: {
                                    Html: { Data: thankYouHtml(clientName, c.eventType, c.eventDate, 'client') },
                                    Text: { Data: `Dear ${clientName},\n\nThank you so much for choosing RNB Events for your ${c.eventType || 'event'}. It was an honor to help bring your vision to life.\n\nWe hope every detail exceeded your expectations. We would love to hear about your experience!\n\nWith gratitude,\nRNB Events\nwww.rnbevents716.com` }
                                }
                            }
                        }));
                    } catch (e) { console.error('Post-event client email error:', e); }
                }

                /* Send thank-you to planner */
                const plannerEmail = (c.plannerEmail || '').trim();
                if (plannerEmail) {
                    const plannerName = c.planner || 'Team';
                    try {
                        await ses.send(new SendEmailCommand({
                            Source: FROM_EMAIL,
                            Destination: { ToAddresses: [plannerEmail.slice(0, 200)] },
                            Message: {
                                Subject: { Data: `Thank You for Your Partnership — ${(c.eventType || 'Event').replace(/[<>"]/g, '')} for ${clientName.replace(/[<>"]/g, '')}` },
                                Body: {
                                    Html: { Data: thankYouHtml(plannerName, c.eventType, c.eventDate, 'planner') },
                                    Text: { Data: `Dear ${plannerName},\n\nThank you for your partnership on the ${c.eventType || 'event'} for ${clientName}. Your collaboration made it a success.\n\nWith gratitude,\nRNB Events\nwww.rnbevents716.com` }
                                }
                            }
                        }));
                    } catch (e) { console.error('Post-event planner email error:', e); }
                }

                /* Archive and disable */
                c.active     = false;
                c.archived   = true;
                c.archivedAt = now.toISOString();
                appendEditLog(c, { ts: now.toISOString(), role: 'rnbTeam', roleName: 'RNB Events (Auto)', action: 'Client archived after event date — thank-you emails sent' });
                processed.push({ id: c.id, name: clientName });
            }

            if (processed.length) await writeClients(clients);
            return respond(200, { ok: true, processed });
        }

        /* ── Admin activity log ──────────────────────── */
        if (path === '/log-admin-activity') {
            const { entries } = body;
            if (!Array.isArray(entries) || !entries.length) return respond(400, { ok: false, error: 'Missing entries' });
            const adminData = await readAdminData();
            if (!adminData.activityLog) adminData.activityLog = [];
            const now = new Date().toISOString();
            entries.forEach(function (e) {
                adminData.activityLog.push({
                    ts:      now,
                    action:  String(e.action  || '').slice(0, 200),
                    details: String(e.details || '').slice(0, 500)
                });
            });
            /* Keep last 500 log entries */
            adminData.activityLog = adminData.activityLog.slice(-500);
            await writeAdminData(adminData);
            return respond(200, { ok: true });
        }

        /* ── Admin analytics stats ──────────────────────────── */
        if (path === '/get-stats') {
            /* Verify admin hash against stored or fallback hash */
            const submittedHash = String(body.codeHash || '').toLowerCase().trim();
            if (!submittedHash || !/^[a-f0-9]{64}$/.test(submittedHash)) {
                return respond(401, { ok: false, error: 'Unauthorized' });
            }
            const adminData = await readAdminData();
            const knownHash = ((adminData.adminCodeHash || '') || '47d538bc9bbdba86910d104f78b851d87356c7fcee36e214878a5a24f7bbedf4').toLowerCase();
            if (submittedHash !== knownHash) {
                return respond(401, { ok: false, error: 'Unauthorized' });
            }

            const days = Math.min(Math.max(parseInt(body.days) || 30, 1), 90);
            const dateKeys = [];
            for (let i = 0; i < days; i++) {
                const d = new Date();
                d.setDate(d.getDate() - i);
                dateKeys.push(d.toISOString().slice(0, 10));
            }

            const files = await Promise.all(
                dateKeys.map(dateKey =>
                    s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: `logs/visits-${dateKey}.ndjson` }))
                        .then(r => r.Body.transformToString())
                        .then(text => ({ dateKey, text }))
                        .catch(() => ({ dateKey, text: '' }))
                )
            );

            const allEntries = [];
            files.forEach(({ text }) => {
                if (!text) return;
                text.split('\n').forEach(line => {
                    line = line.trim();
                    if (!line) return;
                    try { allEntries.push(JSON.parse(line)); } catch (e) {}
                });
            });

            const pageViews = allEntries.filter(e => e.type === 'page_view');
            const clicks    = allEntries.filter(e => e.type === 'click');

            /* By date */
            const byDateMap = {};
            pageViews.forEach(e => {
                const d = (e.ts || '').slice(0, 10);
                byDateMap[d] = (byDateMap[d] || 0) + 1;
            });

            /* By section */
            const bySection = {};
            pageViews.forEach(e => {
                const s = e.section || 'unknown';
                bySection[s] = (bySection[s] || 0) + 1;
            });

            /* Top pages (strip query strings) */
            const byPageMap = {};
            pageViews.forEach(e => {
                let pg = (e.page || 'unknown');
                try { pg = new URL(pg).pathname; } catch (err) { pg = pg.split('?')[0]; }
                byPageMap[pg] = (byPageMap[pg] || 0) + 1;
            });
            const topPages = Object.entries(byPageMap)
                .sort((a, b) => b[1] - a[1]).slice(0, 15)
                .map(([page, count]) => ({ page, count }));

            /* UTM sources */
            const bySourceMap = {};
            allEntries.forEach(e => {
                if (e.utmSource) bySourceMap[e.utmSource] = (bySourceMap[e.utmSource] || 0) + 1;
            });
            const topSources = Object.entries(bySourceMap)
                .sort((a, b) => b[1] - a[1]).slice(0, 10)
                .map(([source, count]) => ({ source, count }));

            /* Top cities */
            const byCityMap = {};
            pageViews.forEach(e => { if (e.city) byCityMap[e.city] = (byCityMap[e.city] || 0) + 1; });
            const topCities = Object.entries(byCityMap)
                .sort((a, b) => b[1] - a[1]).slice(0, 10)
                .map(([city, count]) => ({ city, count }));

            const uniqueSessions = new Set(pageViews.map(e => e.sessionId).filter(Boolean)).size;
            const loadTimes = pageViews.filter(e => e.loadMs != null).map(e => e.loadMs);
            const avgLoadMs = loadTimes.length
                ? Math.round(loadTimes.reduce((a, b) => a + b, 0) / loadTimes.length)
                : null;

            const today = new Date().toISOString().slice(0, 10);
            const todayViews = pageViews.filter(e => (e.ts || '').startsWith(today)).length;

            return respond(200, {
                ok:             true,
                totalViews:     pageViews.length,
                totalClicks:    clicks.length,
                uniqueSessions,
                avgLoadMs,
                todayViews,
                byDate:         Object.entries(byDateMap).sort((a, b) => a[0].localeCompare(b[0])).map(([date, count]) => ({ date, count })),
                bySection,
                topPages,
                topSources,
                topCities
            });
        }

        return respond(404, { ok: false, error: 'Unknown route' });
    } catch (err) {
        console.error(err);
        return respond(500, { ok: false, error: err.message });
    }
};
